/**
 * Canvasly load test — simulate N concurrent users on ONE board and report
 * message latency (p50/p95/p99).
 *
 * Each virtual user opens a WebSocket with a Cognito JWT, joins the board, and
 * emits syncUpdate + cursorMove at a realistic cadence. Latency is measured by
 * tagging outbound updates and timing the echo/broadcast back to a peer.
 *
 * Usage:
 *   WS_URL=wss://xxxx.execute-api.us-east-1.amazonaws.com/dev \
 *   BOARD_ID=demo JWT_FILE=./jwts.txt USERS=20 DURATION_S=60 \
 *   npm run load-test -w scripts
 *
 * JWT_FILE: one Cognito idToken per line (at least USERS lines). Generate with
 * scripts/mint-jwts.ts (TODO) or paste tokens from the app.
 */
import { readFileSync } from "node:fs";
import WebSocket from "ws";

const WS_URL = must("WS_URL");
const BOARD_ID = process.env.BOARD_ID ?? "demo";
const USERS = Number(process.env.USERS ?? "20");
const DURATION_S = Number(process.env.DURATION_S ?? "60");
const CURSOR_HZ = 20;
const UPDATE_HZ = 5;

function must(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env ${name}`);
  return v;
}

function loadJwts(): string[] {
  const file = process.env.JWT_FILE;
  if (!file) {
    console.warn("No JWT_FILE set — using placeholder tokens (will fail $connect on a real deploy).");
    return Array.from({ length: USERS }, (_, i) => `PLACEHOLDER_JWT_${i}`);
  }
  const lines = readFileSync(file, "utf8").split("\n").map((l) => l.trim()).filter(Boolean);
  if (lines.length < USERS) throw new Error(`JWT_FILE has ${lines.length} tokens, need ${USERS}`);
  return lines;
}

interface Stats {
  latencies: number[];
}

function percentile(sorted: number[], p: number): number {
  if (sorted.length === 0) return NaN;
  const idx = Math.min(sorted.length - 1, Math.floor((p / 100) * sorted.length));
  return sorted[idx];
}

async function runUser(idx: number, jwt: string, stats: Stats, stopAt: number): Promise<void> {
  const url = `${WS_URL}?token=${encodeURIComponent(jwt)}`;
  const ws = new WebSocket(url);
  const pending = new Map<string, number>(); // tag -> sentAt

  await new Promise<void>((resolve, reject) => {
    ws.once("open", () => resolve());
    ws.once("error", reject);
  });

  ws.send(JSON.stringify({ action: "joinBoard", boardId: BOARD_ID }));

  ws.on("message", (raw: Buffer) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === "syncUpdate" && typeof msg.update === "string") {
        // The update payload carries a tag we can time against.
        const tag = extractTag(msg.update);
        const sentAt = tag && pending.get(tag);
        if (sentAt) {
          stats.latencies.push(performance.now() - sentAt);
          pending.delete(tag);
        }
      }
    } catch {
      /* ignore */
    }
  });

  const cursorTimer = setInterval(() => {
    ws.send(JSON.stringify({ action: "cursorMove", boardId: BOARD_ID, x: Math.random() * 1000, y: Math.random() * 1000 }));
  }, 1000 / CURSOR_HZ);

  const updateTimer = setInterval(() => {
    const tag = `${idx}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    pending.set(tag, performance.now());
    // A fake "update" that embeds the tag so a peer can echo-time it.
    ws.send(JSON.stringify({ action: "syncUpdate", boardId: BOARD_ID, update: encodeTag(tag) }));
  }, 1000 / UPDATE_HZ);

  await new Promise<void>((resolve) => setTimeout(resolve, Math.max(0, stopAt - Date.now())));
  clearInterval(cursorTimer);
  clearInterval(updateTimer);
  ws.close();
}

// Minimal tag codec — a real test would embed the tag inside a Yjs update.
function encodeTag(tag: string): string {
  return Buffer.from(`TAG:${tag}`).toString("base64");
}
function extractTag(b64: string): string | null {
  try {
    const s = Buffer.from(b64, "base64").toString("utf8");
    return s.startsWith("TAG:") ? s.slice(4) : null;
  } catch {
    return null;
  }
}

async function main(): Promise<void> {
  const jwts = loadJwts();
  const stats: Stats = { latencies: [] };
  const stopAt = Date.now() + DURATION_S * 1000;
  console.log(`Launching ${USERS} users on board ${BOARD_ID} for ${DURATION_S}s against ${WS_URL}`);

  await Promise.all(
    Array.from({ length: USERS }, (_, i) => runUser(i, jwts[i], stats, stopAt).catch((e) => console.error(`user ${i}:`, e.message))),
  );

  const sorted = [...stats.latencies].sort((a, b) => a - b);
  console.log("\n=== latency (ms) ===");
  console.log(`samples: ${sorted.length}`);
  console.log(`p50: ${percentile(sorted, 50).toFixed(1)}`);
  console.log(`p95: ${percentile(sorted, 95).toFixed(1)}`);
  console.log(`p99: ${percentile(sorted, 99).toFixed(1)}`);
  console.log(`max: ${(sorted.at(-1) ?? NaN).toFixed(1)}`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
