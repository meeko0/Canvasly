// $connect route: verify the Cognito JWT passed as the `token` query-string
// param, assign the user a stable color, and accept (200) or reject (401).
//
// The board is unknown at $connect, so we persist NO board membership here.
// We DO need the verified identity to survive to joinBoard (whose messages
// carry no token). Two supported flows:
//   1. API Gateway Lambda authorizer on $connect — the verified `sub` lands in
//      `event.requestContext.authorizer` on every subsequent route. Preferred.
//   2. This inline verifier, which stamps the identity onto the connection via
//      a short-lived identity row keyed by connectionId. We pick (1): this
//      handler can be wired as the authorizer, or as the $connect integration
//      when the authorizer echoes identity through the context.
//
// Here we simply verify + accept/reject. `readIdentity` (ws.ts) reads whichever
// of the two flows populated the request context.

import type {
  APIGatewayProxyWebsocketEventV2,
  APIGatewayProxyResultV2,
} from "aws-lambda";
import { verifyJwt } from "../lib/auth.js";
import { colorForUser } from "../lib/color.js";
import { result } from "../lib/ws.js";

interface ConnectEvent extends APIGatewayProxyWebsocketEventV2 {
  queryStringParameters?: Record<string, string | undefined>;
}

export async function handler(
  event: ConnectEvent,
): Promise<APIGatewayProxyResultV2> {
  const token = event.queryStringParameters?.token;
  if (!token) return result(401, "Missing token");

  try {
    const user = await verifyJwt(token);
    // Deterministic color from userId; validated here, recomputed at joinBoard.
    colorForUser(user.userId);
    return result(200, "OK");
  } catch {
    return result(401, "Unauthorized");
  }
}
