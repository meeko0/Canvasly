// leaveBoard route: delete this connection's row and tell peers the user left.

import type {
  APIGatewayProxyWebsocketEventV2,
  APIGatewayProxyResultV2,
} from "aws-lambda";
import type { LeaveBoardMsg, UserLeftMsg } from "@canvasly/shared";
import { broadcast } from "../lib/apigw.js";
import { getConnection, deleteConnection } from "../lib/connections.js";
import { forget } from "../lib/rateLimit.js";
import { bindEndpoint, connId, ok, parseBody, replyError } from "../lib/ws.js";

export async function handler(
  event: APIGatewayProxyWebsocketEventV2,
): Promise<APIGatewayProxyResultV2> {
  bindEndpoint(event);
  const connectionId = connId(event);

  const msg = parseBody(event) as LeaveBoardMsg | null;
  if (!msg || msg.action !== "leaveBoard" || !msg.boardId) {
    await replyError(event, "BAD_REQUEST", "Expected leaveBoard with boardId");
    return ok();
  }

  const conn = await getConnection(connectionId);
  // Idempotent: if the row is already gone, just ack.
  if (!conn) return ok();

  await deleteConnection(connectionId);
  forget(connectionId);

  const left: UserLeftMsg = {
    type: "userLeft",
    connectionId,
    userId: conn.userId,
  };
  await broadcast(msg.boardId, connectionId, left);
  return ok();
}
