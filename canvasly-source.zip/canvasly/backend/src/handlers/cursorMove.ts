// cursorMove route: ephemeral cursor position. Broadcast only, never persisted.
// Rate-limited per connection (shares the bucket with syncUpdate).

import type {
  APIGatewayProxyWebsocketEventV2,
  APIGatewayProxyResultV2,
} from "aws-lambda";
import type { CursorMoveMsg, CursorMoveBroadcast } from "@canvasly/shared";
import { broadcast } from "../lib/apigw.js";
import { getConnection } from "../lib/connections.js";
import { allow } from "../lib/rateLimit.js";
import { bindEndpoint, connId, ok, parseBody, replyError } from "../lib/ws.js";

export async function handler(
  event: APIGatewayProxyWebsocketEventV2,
): Promise<APIGatewayProxyResultV2> {
  bindEndpoint(event);
  const connectionId = connId(event);

  if (!allow(connectionId)) {
    // Cursor spam is dropped silently — no error reply, just skip.
    return ok();
  }

  const msg = parseBody(event) as CursorMoveMsg | null;
  if (
    !msg ||
    msg.action !== "cursorMove" ||
    !msg.boardId ||
    typeof msg.x !== "number" ||
    typeof msg.y !== "number"
  ) {
    await replyError(event, "BAD_REQUEST", "Expected cursorMove with boardId+x+y");
    return ok();
  }

  const conn = await getConnection(connectionId);
  if (!conn || conn.boardId !== msg.boardId) {
    await replyError(event, "FORBIDDEN", "Not joined to this board");
    return ok();
  }

  const payload: CursorMoveBroadcast = {
    type: "cursorMove",
    connectionId,
    userId: conn.userId,
    x: msg.x,
    y: msg.y,
  };
  await broadcast(msg.boardId, connectionId, payload);
  return ok();
}
