// joinBoard route: check membership, write the Connections row (with TTL),
// return the latest snapshot (presigned) + updates-since, list peers, and
// broadcast userJoined. Core of the vertical slice.

import type {
  APIGatewayProxyWebsocketEventV2,
  APIGatewayProxyResultV2,
} from "aws-lambda";
import { PutCommand } from "@aws-sdk/lib-dynamodb";
import type {
  JoinBoardMsg,
  JoinedMsg,
  UserJoinedMsg,
  Peer,
  ConnectionRow,
} from "@canvasly/shared";
import { ddb } from "../lib/ddb.js";
import { env } from "../lib/env.js";
import { broadcast, listBoardConnections } from "../lib/apigw.js";
import { presignSnapshotGet } from "../lib/s3.js";
import { colorForUser } from "../lib/color.js";
import {
  bindEndpoint,
  connId,
  ok,
  parseBody,
  readIdentity,
  reply,
  replyError,
  result,
} from "../lib/ws.js";
import { checkMembership } from "../permissions/checkMembership.js";
import { latestSnapshot, updatesSinceSnapshot } from "../lib/updateLog.js";

export async function handler(
  event: APIGatewayProxyWebsocketEventV2,
): Promise<APIGatewayProxyResultV2> {
  bindEndpoint(event);

  const identity = readIdentity(event);
  if (!identity) {
    await replyError(event, "UNAUTHORIZED", "No verified identity on connection");
    return result(401);
  }

  const msg = parseBody(event) as JoinBoardMsg | null;
  if (!msg || msg.action !== "joinBoard" || !msg.boardId) {
    await replyError(event, "BAD_REQUEST", "Expected joinBoard with boardId");
    return ok();
  }
  const { boardId } = msg;
  const connectionId = connId(event);

  // 1. Membership + role.
  const role = await checkMembership(boardId, identity.userId);
  if (!role) {
    await replyError(event, "FORBIDDEN", "Not a member of this board");
    return ok();
  }

  const color = colorForUser(identity.userId);
  const nowSec = Math.floor(Date.now() / 1000);

  // 2. Peers already present (before we add ourselves).
  const existing = await listBoardConnections(boardId);

  // 3. Write our Connections row with TTL.
  const row: ConnectionRow = {
    connectionId,
    boardId,
    userId: identity.userId,
    displayName: identity.displayName,
    color,
    connectedAt: nowSec,
    ttl: nowSec + env.CONNECTION_TTL_SECONDS,
  };
  await ddb().send(
    new PutCommand({ TableName: env.CONNECTIONS_TABLE, Item: row }),
  );

  // 4. Latest snapshot -> presigned GET; updates since snapshot.
  const snap = await latestSnapshot(boardId);
  const snapshotUrl = snap ? await presignSnapshotGet(snap.s3Key) : null;
  const updates = await updatesSinceSnapshot(boardId);

  // 5. Build peer list (needs displayName/color — fetch from each row is heavy;
  //    we only have connectionId/userId from the GSI projection, so derive
  //    color and use userId as a fallback name until a richer projection).
  const peers: Peer[] = existing
    .filter((c) => c.connectionId !== connectionId)
    .map((c) => ({
      userId: c.userId,
      connectionId: c.connectionId,
      displayName: c.userId, // TODO(canvasly): widen byBoard projection to include displayName
      color: colorForUser(c.userId),
    }));

  // 6. Ack back to the joiner.
  const joined: JoinedMsg = {
    type: "joined",
    boardId,
    snapshotUrl,
    updatesSinceSnapshot: updates,
    peers,
    role,
  };
  await reply(event, joined);

  // 7. Tell everyone else the joiner arrived.
  const userJoined: UserJoinedMsg = {
    type: "userJoined",
    peer: {
      userId: identity.userId,
      connectionId,
      displayName: identity.displayName,
      color,
    },
  };
  await broadcast(boardId, connectionId, userJoined);

  return ok();
}
