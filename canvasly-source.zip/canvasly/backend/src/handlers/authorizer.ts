// $connect request authorizer: verifies the Cognito JWT from the `token`
// query-string param and returns an IAM allow/deny plus the verified identity
// (userId, displayName, color) in the authorizer context.
//
// API Gateway persists this context for the life of the connection, so EVERY
// later route ($request-based joinBoard/syncUpdate/...) can read the identity
// via `event.requestContext.authorizer` (see readIdentity in lib/ws.ts). This
// is the flow the connect.ts comment calls "preferred": messages after
// $connect carry no token, so the identity must be established exactly once,
// here, and carried forward by the gateway.

import type {
  APIGatewayRequestAuthorizerEventV2,
  APIGatewaySimpleAuthorizerWithContextResult,
} from "aws-lambda";
import { verifyJwt } from "../lib/auth.js";
import { colorForUser } from "../lib/color.js";

interface IdentityContext extends Record<string, string | number | boolean> {
  userId: string;
  displayName: string;
  color: string;
}

/**
 * WebSocket Lambda authorizer (simple response format with context).
 * `identitySource` is configured in the CDK as `route.request.querystring.token`.
 */
export async function handler(
  event: APIGatewayRequestAuthorizerEventV2,
): Promise<APIGatewaySimpleAuthorizerWithContextResult<IdentityContext>> {
  const token =
    event.queryStringParameters?.token ??
    event.queryStringParameters?.Authorization;

  const deny: APIGatewaySimpleAuthorizerWithContextResult<IdentityContext> = {
    isAuthorized: false,
    context: { userId: "", displayName: "", color: "" },
  };

  if (!token) return deny;

  try {
    const user = await verifyJwt(token);
    return {
      isAuthorized: true,
      context: {
        userId: user.userId,
        displayName: user.displayName,
        color: colorForUser(user.userId),
      },
    };
  } catch {
    return deny;
  }
}
