// syncUpdate route: a Yjs update from a client. Reject viewers (FORBIDDEN),
// otherwise broadcast to every other connection on the board, reap gone
// connections, append to the update log, and compact when the threshold hits.

import type {
  APIGatewayProxyWebsocketEventV2,
  APIGatewayProxyResultV2,
} from "aws-lambda";
import type { SyncUpdateMsg, SyncUpdateBroadcast } from "@canvasly/shared";
import { MAX_WS_PAYLOAD_BYTES } from "@canvasly/shared";
import { broadcast } from "../lib/apigw.js";
import { getConnection } from "../lib/connections.js";
import { canWrite, checkMembership } from "../permissions/checkMembership.js";
import { allow } from "../lib/rateLimit.js";
import { appendUpdate, maybeCompact } from "../lib/updateLog.js";
import {
  bindEndpoint,
  connId,
  ok,
  parseBody,
  replyError,
} from "../lib/ws.js";

export async function handler(
  event: APIGatewayProxyWebsocketEventV2,
): Promise<APIGatewayProxyResultV2> {
  bindEndpoint(event);
  const connectionId = connId(event);

  // Per-connection rate limit (shared with cursorMove).
  if (!allow(connectionId)) {
    await replyError(event, "RATE_LIMITED", "Too many messages");
    return ok();
  }

  const msg = parseBody(event) as SyncUpdateMsg | null;
  if (!msg || msg.action !== "syncUpdate" || !msg.boardId || !msg.update) {
    await replyError(event, "BAD_REQUEST", "Expected syncUpdate with boardId+update");
    return ok();
  }
  if (msg.update.length > MAX_WS_PAYLOAD_BYTES) {
    await replyError(event, "BAD_REQUEST", "Update exceeds max payload size");
    return ok();
  }

  // Resolve the sender's identity + role from their connection row.
  const conn = await getConnection(connectionId);
  if (!conn || conn.boardId !== msg.boardId) {
    await replyError(event, "FORBIDDEN", "Not joined to this board");
    return ok();
  }
  const role = await checkMembership(msg.boardId, conn.userId);
  if (!role || !canWrite(role)) {
    await replyError(event, "FORBIDDEN", "Viewers cannot edit");
    return ok();
  }

  // Broadcast to every other connection; reap gone connections.
  const payload: SyncUpdateBroadcast = {
    type: "syncUpdate",
    update: msg.update,
    from: connectionId,
  };
  await broadcast(msg.boardId, connectionId, payload);

  // Persist to the update log and compact if we crossed the threshold.
  const count = await appendUpdate(msg.boardId, msg.update);
  await maybeCompact(msg.boardId, count);

  return ok();
}
