// ping route: keepalive. Returns a pong over the socket.

import type {
  APIGatewayProxyWebsocketEventV2,
  APIGatewayProxyResultV2,
} from "aws-lambda";
import type { PongMsg } from "@canvasly/shared";
import { bindEndpoint, ok, reply } from "../lib/ws.js";

export async function handler(
  event: APIGatewayProxyWebsocketEventV2,
): Promise<APIGatewayProxyResultV2> {
  bindEndpoint(event);
  const pong: PongMsg = { type: "pong" };
  await reply(event, pong);
  return ok();
}
