// presence route: ephemeral selection/presence. Broadcast only, never persisted.

import type {
  APIGatewayProxyWebsocketEventV2,
  APIGatewayProxyResultV2,
} from "aws-lambda";
import type { PresenceMsg, PresenceBroadcast } from "@canvasly/shared";
import { broadcast } from "../lib/apigw.js";
import { getConnection } from "../lib/connections.js";
import { allow } from "../lib/rateLimit.js";
import { bindEndpoint, connId, ok, parseBody, replyError } from "../lib/ws.js";

export async function handler(
  event: APIGatewayProxyWebsocketEventV2,
): Promise<APIGatewayProxyResultV2> {
  bindEndpoint(event);
  const connectionId = connId(event);

  if (!allow(connectionId)) return ok();

  const msg = parseBody(event) as PresenceMsg | null;
  if (
    !msg ||
    msg.action !== "presence" ||
    !msg.boardId ||
    !Array.isArray(msg.selectedIds)
  ) {
    await replyError(event, "BAD_REQUEST", "Expected presence with boardId+selectedIds");
    return ok();
  }

  const conn = await getConnection(connectionId);
  if (!conn || conn.boardId !== msg.boardId) {
    await replyError(event, "FORBIDDEN", "Not joined to this board");
    return ok();
  }

  const payload: PresenceBroadcast = {
    type: "presence",
    connectionId,
    userId: conn.userId,
    selectedIds: msg.selectedIds,
  };
  await broadcast(msg.boardId, connectionId, payload);
  return ok();
}
