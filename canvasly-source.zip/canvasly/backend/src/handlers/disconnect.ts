// $disconnect route: the socket dropped. Delete the connection row and tell
// peers the user left. The connection row carries the boardId we need to
// target the broadcast (the $disconnect event body is empty).

import type {
  APIGatewayProxyWebsocketEventV2,
  APIGatewayProxyResultV2,
} from "aws-lambda";
import type { UserLeftMsg } from "@canvasly/shared";
import { broadcast } from "../lib/apigw.js";
import { getConnection, deleteConnection } from "../lib/connections.js";
import { forget } from "../lib/rateLimit.js";
import { bindEndpoint, connId, ok } from "../lib/ws.js";

export async function handler(
  event: APIGatewayProxyWebsocketEventV2,
): Promise<APIGatewayProxyResultV2> {
  bindEndpoint(event);
  const connectionId = connId(event);

  const conn = await getConnection(connectionId);
  // Already reaped (TTL or a GoneException cleanup) — nothing to do.
  if (!conn) {
    forget(connectionId);
    return ok();
  }

  await deleteConnection(connectionId);
  forget(connectionId);

  const left: UserLeftMsg = {
    type: "userLeft",
    connectionId,
    userId: conn.userId,
  };
  await broadcast(conn.boardId, connectionId, left);
  return ok();
}
