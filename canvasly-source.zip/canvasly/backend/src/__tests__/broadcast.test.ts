// broadcast() must post to every other connection on the board and delete the
// Connections rows of any connection that returns GoneException.

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import type { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import {
  ApiGatewayManagementApiClient,
  GoneException,
  PostToConnectionCommand,
} from "@aws-sdk/client-apigatewaymanagementapi";
import { DeleteCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { __setDdbForTests } from "../lib/ddb.js";
import { __setApigwForTests, broadcast } from "../lib/apigw.js";

process.env.CONNECTIONS_TABLE = "conns-test";

describe("broadcast GoneException cleanup", () => {
  beforeEach(() => {
    __setDdbForTests(undefined);
    __setApigwForTests(undefined);
  });
  afterEach(() => {
    __setDdbForTests(undefined);
    __setApigwForTests(undefined);
  });

  it("posts to live peers and deletes rows that are Gone", async () => {
    // byBoard GSI returns three connections: sender (excluded), one live, one gone.
    const deletedKeys: unknown[] = [];
    const ddbSend = vi.fn().mockImplementation((cmd: unknown) => {
      if (cmd instanceof QueryCommand) {
        return Promise.resolve({
          Items: [
            { connectionId: "sender", userId: "u0" },
            { connectionId: "live", userId: "u1" },
            { connectionId: "gone", userId: "u2" },
          ],
        });
      }
      if (cmd instanceof DeleteCommand) {
        deletedKeys.push((cmd as DeleteCommand).input.Key);
        return Promise.resolve({});
      }
      return Promise.resolve({});
    });
    __setDdbForTests({ send: ddbSend } as unknown as DynamoDBDocumentClient);

    const posted: string[] = [];
    const apigwSend = vi.fn().mockImplementation((cmd: unknown) => {
      const id = (cmd as PostToConnectionCommand).input.ConnectionId!;
      if (id === "gone") {
        return Promise.reject(
          new GoneException({ message: "gone", $metadata: {} }),
        );
      }
      posted.push(id);
      return Promise.resolve({});
    });
    __setApigwForTests(
      { send: apigwSend } as unknown as ApiGatewayManagementApiClient,
    );

    const reaped = await broadcast("b1", "sender", {
      type: "pong",
    });

    // "sender" excluded; "live" got the post; "gone" was reaped.
    expect(posted).toEqual(["live"]);
    expect(reaped).toEqual(["gone"]);
    expect(deletedKeys).toEqual([{ connectionId: "gone" }]);
  });
});
