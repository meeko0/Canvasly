// Tests for checkMembership: owner/editor/viewer/none.

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import type { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { __setDdbForTests } from "../lib/ddb.js";
import { checkMembership, canWrite } from "../permissions/checkMembership.js";

process.env.BOARD_MEMBERS_TABLE = "members-test";

function mockDdb(item: unknown) {
  return {
    send: vi.fn().mockResolvedValue({ Item: item }),
  } as unknown as DynamoDBDocumentClient;
}

describe("checkMembership", () => {
  beforeEach(() => __setDdbForTests(undefined));
  afterEach(() => __setDdbForTests(undefined));

  it("returns 'owner' for an owner row", async () => {
    __setDdbForTests(mockDdb({ boardId: "b1", userId: "u1", role: "owner" }));
    expect(await checkMembership("b1", "u1")).toBe("owner");
  });

  it("returns 'editor' for an editor row", async () => {
    __setDdbForTests(mockDdb({ boardId: "b1", userId: "u2", role: "editor" }));
    expect(await checkMembership("b1", "u2")).toBe("editor");
  });

  it("returns 'viewer' for a viewer row", async () => {
    __setDdbForTests(mockDdb({ boardId: "b1", userId: "u3", role: "viewer" }));
    expect(await checkMembership("b1", "u3")).toBe("viewer");
  });

  it("returns null when there is no membership row", async () => {
    __setDdbForTests(mockDdb(undefined));
    expect(await checkMembership("b1", "nobody")).toBeNull();
  });
});

describe("canWrite", () => {
  it("allows owner and editor, denies viewer", () => {
    expect(canWrite("owner")).toBe(true);
    expect(canWrite("editor")).toBe(true);
    expect(canWrite("viewer")).toBe(false);
  });
});
