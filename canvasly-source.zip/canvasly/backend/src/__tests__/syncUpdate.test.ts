// syncUpdate must reject a viewer with FORBIDDEN and must NOT broadcast.

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import type { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import type { ApiGatewayManagementApiClient } from "@aws-sdk/client-apigatewaymanagementapi";
import { __setDdbForTests } from "../lib/ddb.js";
import { __setApigwForTests } from "../lib/apigw.js";
import { __resetRateLimits } from "../lib/rateLimit.js";
import { handler } from "../handlers/syncUpdate.js";

process.env.CONNECTIONS_TABLE = "conns-test";
process.env.BOARD_MEMBERS_TABLE = "members-test";

function buildEvent(connectionId: string, body: unknown) {
  return {
    requestContext: {
      connectionId,
      domainName: "example.com",
      stage: "prod",
    },
    body: JSON.stringify(body),
  } as never;
}

describe("syncUpdate role enforcement", () => {
  beforeEach(() => {
    __resetRateLimits();
    __setDdbForTests(undefined);
    __setApigwForTests(undefined);
  });
  afterEach(() => {
    __resetRateLimits();
    __setDdbForTests(undefined);
    __setApigwForTests(undefined);
  });

  it("rejects a viewer and never broadcasts", async () => {
    // ddb routes by table: connection row, then a viewer membership row.
    const ddbSend = vi.fn().mockImplementation((cmd: { input: { TableName: string } }) => {
      const table = cmd.input.TableName;
      if (table === "conns-test") {
        return Promise.resolve({
          Item: {
            connectionId: "c-viewer",
            boardId: "b1",
            userId: "u-viewer",
          },
        });
      }
      if (table === "members-test") {
        return Promise.resolve({ Item: { boardId: "b1", userId: "u-viewer", role: "viewer" } });
      }
      return Promise.resolve({});
    });
    __setDdbForTests({ send: ddbSend } as unknown as DynamoDBDocumentClient);

    // apigw: record every post. A FORBIDDEN error reply is expected (1 post);
    // NO broadcast query/post beyond that single reply to the sender.
    const posts: unknown[] = [];
    const apigwSend = vi.fn().mockImplementation((cmd: { input: unknown }) => {
      posts.push(cmd.input);
      return Promise.resolve({});
    });
    __setApigwForTests({ send: apigwSend } as unknown as ApiGatewayManagementApiClient);

    const res = await handler(
      buildEvent("c-viewer", {
        action: "syncUpdate",
        boardId: "b1",
        update: "AAAA",
      }),
    );

    expect(res).toMatchObject({ statusCode: 200 });

    // Exactly one post: the FORBIDDEN error reply to the sender.
    expect(apigwSend).toHaveBeenCalledTimes(1);
    const sent = JSON.parse(
      new TextDecoder().decode((posts[0] as { Data: Uint8Array }).Data),
    );
    expect(sent).toMatchObject({ type: "error", code: "FORBIDDEN" });

    // No byBoard Query ran (broadcast never reached) — only the two Gets did.
    const queried = ddbSend.mock.calls.some((call: unknown[]) => {
      const cmd = call[0] as { constructor: { name: string } };
      return cmd.constructor.name === "QueryCommand";
    });
    expect(queried).toBe(false);
  });
});
