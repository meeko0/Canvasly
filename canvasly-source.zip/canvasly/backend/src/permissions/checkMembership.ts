// Board membership + role resolution. Reads the BoardMembers table
// (PK boardId, SK userId). Returns the role, or null when the user is not a
// member — callers reject that with FORBIDDEN.

import { GetCommand } from "@aws-sdk/lib-dynamodb";
import type { Role, BoardMemberRow } from "@canvasly/shared";
import { ddb } from "../lib/ddb.js";
import { env } from "../lib/env.js";

/**
 * Look up a user's role on a board. Returns the Role, or null if the user is
 * not a member (no row).
 */
export async function checkMembership(
  boardId: string,
  userId: string,
): Promise<Role | null> {
  const out = await ddb().send(
    new GetCommand({
      TableName: env.BOARD_MEMBERS_TABLE,
      Key: { boardId, userId },
    }),
  );
  const row = out.Item as BoardMemberRow | undefined;
  return row?.role ?? null;
}

/** True if the role is allowed to mutate the document (owner or editor). */
export function canWrite(role: Role): boolean {
  return role === "owner" || role === "editor";
}
