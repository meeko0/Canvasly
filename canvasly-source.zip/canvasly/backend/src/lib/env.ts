// Environment configuration — reads table/bucket/pool names from the Lambda env.
// No secrets live here; CDK injects these at deploy time.

function required(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}

function optional(name: string, fallback: string): string {
  return process.env[name] ?? fallback;
}

export const env = {
  get CONNECTIONS_TABLE(): string {
    return required("CONNECTIONS_TABLE");
  },
  get BOARDS_TABLE(): string {
    return required("BOARDS_TABLE");
  },
  get BOARD_MEMBERS_TABLE(): string {
    return required("BOARD_MEMBERS_TABLE");
  },
  get BOARD_SNAPSHOTS_TABLE(): string {
    return required("BOARD_SNAPSHOTS_TABLE");
  },
  get SNAPSHOTS_BUCKET(): string {
    return required("SNAPSHOTS_BUCKET");
  },
  get COGNITO_USER_POOL_ID(): string {
    return required("COGNITO_USER_POOL_ID");
  },
  get COGNITO_CLIENT_ID(): string {
    return required("COGNITO_CLIENT_ID");
  },
  get AWS_REGION(): string {
    return optional("AWS_REGION", "us-east-1");
  },
  /** Connections GSI that lists every connection on a board. */
  BY_BOARD_INDEX: "byBoard",
  /** How long (seconds) a Connections row lives before DynamoDB TTL reaps it. */
  CONNECTION_TTL_SECONDS: 3 * 60 * 60,
  /** Presigned snapshot GET URL lifetime (seconds). */
  SNAPSHOT_URL_TTL_SECONDS: 300,
};
