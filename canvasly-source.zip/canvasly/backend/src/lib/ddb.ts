// DynamoDB DocumentClient singleton (marshalling on, empty values removed).

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

let doc: DynamoDBDocumentClient | undefined;

/** Lazily construct a shared DocumentClient reused across warm invocations. */
export function ddb(): DynamoDBDocumentClient {
  if (!doc) {
    const base = new DynamoDBClient({});
    doc = DynamoDBDocumentClient.from(base, {
      marshallOptions: {
        removeUndefinedValues: true,
        convertClassInstanceToMap: true,
      },
    });
  }
  return doc;
}

/** Test seam: inject a mock DocumentClient. */
export function __setDdbForTests(client: DynamoDBDocumentClient | undefined): void {
  doc = client;
}