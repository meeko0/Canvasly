// Deterministic per-user cursor/selection color. Same userId -> same hue
// across sessions and across connections, so a user keeps one color.

const PALETTE = [
  "#e6194b", "#3cb44b", "#ffe119", "#4363d8", "#f58231",
  "#911eb4", "#46f0f0", "#f032e6", "#bcf60c", "#fabebe",
  "#008080", "#e6beff", "#9a6324", "#800000", "#808000",
  "#000075", "#ff7f50", "#2e8b57", "#1e90ff", "#d2691e",
] as const;

/** FNV-1a 32-bit hash — stable, no deps. */
function hash(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

/** Pick a stable palette color for a user. */
export function colorForUser(userId: string): string {
  return PALETTE[hash(userId) % PALETTE.length]!;
}
