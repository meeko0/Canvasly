// Cognito JWT verification. Verifies signature + exp against the user pool
// JWKS using aws-jwt-verify (JWKS cached in-process across warm invocations).

import { CognitoJwtVerifier } from "aws-jwt-verify";
import { env } from "./env.js";

type Verifier = ReturnType<typeof CognitoJwtVerifier.create>;

let verifier: Verifier | undefined;

function getVerifier(): Verifier {
  if (!verifier) {
    verifier = CognitoJwtVerifier.create({
      userPoolId: env.COGNITO_USER_POOL_ID,
      tokenUse: "id",
      clientId: env.COGNITO_CLIENT_ID,
    });
  }
  return verifier;
}

export interface VerifiedUser {
  userId: string;
  displayName: string;
}

/**
 * Verify a Cognito ID token. Throws if invalid/expired. Returns the stable
 * user id (sub) and a display name derived from standard claims.
 */
export async function verifyJwt(token: string): Promise<VerifiedUser> {
  const payload = await getVerifier().verify(token);
  const userId = String(payload.sub);
  const displayName =
    (payload["name"] as string | undefined) ??
    (payload["cognito:username"] as string | undefined) ??
    (payload["email"] as string | undefined) ??
    userId;
  return { userId, displayName };
}

/** Test seam: inject a fake verifier. */
export function __setVerifierForTests(v: Verifier | undefined): void {
  verifier = v;
}
