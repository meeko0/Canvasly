// Connections table access helpers (read one row, delete rows).

import { GetCommand, DeleteCommand } from "@aws-sdk/lib-dynamodb";
import type { ConnectionRow } from "@canvasly/shared";
import { ddb } from "./ddb.js";
import { env } from "./env.js";

/** Read a single connection row, or null if gone. */
export async function getConnection(
  connectionId: string,
): Promise<ConnectionRow | null> {
  const out = await ddb().send(
    new GetCommand({
      TableName: env.CONNECTIONS_TABLE,
      Key: { connectionId },
    }),
  );
  return (out.Item as ConnectionRow | undefined) ?? null;
}

/** Delete a single connection row. */
export async function deleteConnection(connectionId: string): Promise<void> {
  await ddb().send(
    new DeleteCommand({
      TableName: env.CONNECTIONS_TABLE,
      Key: { connectionId },
    }),
  );
}
