// API Gateway Management API client factory + board broadcast fan-out.
//
// `broadcast` queries the Connections "byBoard" GSI for every live connection
// on a board, posts the payload to each (optionally excluding the sender), and
// deletes rows whose connection is gone (GoneException) so stale fan-out
// targets self-heal. Returns the connectionIds that were reaped.

import {
  ApiGatewayManagementApiClient,
  PostToConnectionCommand,
  GoneException,
} from "@aws-sdk/client-apigatewaymanagementapi";
import { QueryCommand, DeleteCommand } from "@aws-sdk/lib-dynamodb";
import type { ServerMessage } from "@canvasly/shared";
import { ddb } from "./ddb.js";
import { env } from "./env.js";

let client: ApiGatewayManagementApiClient | undefined;
let testLocked = false;

/**
 * Build (once) the management client. The callback endpoint is supplied by the
 * WebSocket event domain/stage; we read it from env so tests can stub it.
 */
export function apigw(): ApiGatewayManagementApiClient {
  if (!client) {
    const endpoint = process.env.APIGW_ENDPOINT;
    client = new ApiGatewayManagementApiClient(
      endpoint ? { endpoint } : {},
    );
  }
  return client;
}

/** Build the callback endpoint from a WebSocket request context. */
export function endpointFromContext(domainName: string, stage: string): string {
  return `https://${domainName}/${stage}`;
}

/** Override the endpoint for the current invocation (set from the event). */
export function setApigwEndpoint(endpoint: string): void {
  // A test-injected client wins over per-invocation endpoint binding.
  if (testLocked) return;
  client = new ApiGatewayManagementApiClient({ endpoint });
}

/** Test seam: inject a mock management client (and lock out endpoint rebinds). */
export function __setApigwForTests(
  c: ApiGatewayManagementApiClient | undefined,
): void {
  client = c;
  testLocked = c !== undefined;
}

const enc = new TextEncoder();

/** Post a single server message to one connection. Throws on failure. */
export async function postToConnection(
  connectionId: string,
  payload: ServerMessage,
): Promise<void> {
  await apigw().send(
    new PostToConnectionCommand({
      ConnectionId: connectionId,
      Data: enc.encode(JSON.stringify(payload)),
    }),
  );
}

/**
 * Fan a payload out to every connection on `boardId` except `excludeConnId`.
 * Connections that return GoneException are deleted from the table.
 * Resolves to the list of reaped connectionIds.
 */
export async function broadcast(
  boardId: string,
  excludeConnId: string | null,
  payload: ServerMessage,
): Promise<string[]> {
  const conns = await listBoardConnections(boardId);
  const reaped: string[] = [];
  const body = enc.encode(JSON.stringify(payload));

  await Promise.all(
    conns
      .filter((c) => c.connectionId !== excludeConnId)
      .map(async (c) => {
        try {
          await apigw().send(
            new PostToConnectionCommand({
              ConnectionId: c.connectionId,
              Data: body,
            }),
          );
        } catch (err) {
          if (err instanceof GoneException || (err as Error)?.name === "GoneException") {
            reaped.push(c.connectionId);
            await ddb().send(
              new DeleteCommand({
                TableName: env.CONNECTIONS_TABLE,
                Key: { connectionId: c.connectionId },
              }),
            );
          } else {
            throw err;
          }
        }
      }),
  );

  return reaped;
}

/** Query the byBoard GSI for every connection row on a board. */
export async function listBoardConnections(
  boardId: string,
): Promise<{ connectionId: string; userId: string }[]> {
  const out = await ddb().send(
    new QueryCommand({
      TableName: env.CONNECTIONS_TABLE,
      IndexName: env.BY_BOARD_INDEX,
      KeyConditionExpression: "boardId = :b",
      ExpressionAttributeValues: { ":b": boardId },
      ProjectionExpression: "connectionId, userId",
    }),
  );
  return (out.Items ?? []).map((i) => ({
    connectionId: i.connectionId as string,
    userId: i.userId as string,
  }));
}
