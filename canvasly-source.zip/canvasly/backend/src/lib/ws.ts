// Shared handler plumbing: Lambda proxy responses, event parsing, per-message
// reply/error helpers, and connection-identity lookup.

import type {
  APIGatewayProxyWebsocketEventV2,
  APIGatewayProxyResultV2,
} from "aws-lambda";
import type { ClientMessage, ErrorCode, ServerMessage } from "@canvasly/shared";
import { postToConnection, setApigwEndpoint, endpointFromContext } from "./apigw.js";

/** A plain 200/4xx proxy result (API GW WebSocket ignores the body). */
export function result(statusCode: number, body = ""): APIGatewayProxyResultV2 {
  return { statusCode, body };
}

export const ok = (): APIGatewayProxyResultV2 => result(200, "OK");

/** Parse `event.body` as a ClientMessage; returns null if malformed. */
export function parseBody(
  event: APIGatewayProxyWebsocketEventV2,
): ClientMessage | null {
  if (!event.body) return null;
  try {
    const parsed = JSON.parse(event.body);
    if (parsed && typeof parsed === "object" && typeof parsed.action === "string") {
      return parsed as ClientMessage;
    }
    return null;
  } catch {
    return null;
  }
}

/** The connection id for this WebSocket event. */
export function connId(event: APIGatewayProxyWebsocketEventV2): string {
  return event.requestContext.connectionId;
}

export interface ConnectionIdentity {
  userId: string;
  displayName: string;
}

/**
 * Read the verified identity stamped onto the request by the $connect Lambda
 * authorizer (requestContext.authorizer). Returns null if absent — the caller
 * rejects with UNAUTHORIZED.
 */
export function readIdentity(
  event: APIGatewayProxyWebsocketEventV2,
): ConnectionIdentity | null {
  const auth = (event.requestContext as { authorizer?: Record<string, unknown> })
    .authorizer;
  if (!auth) return null;
  const userId = auth["userId"] ?? auth["sub"] ?? auth["principalId"];
  if (typeof userId !== "string" || userId.length === 0) return null;
  const displayName =
    (typeof auth["displayName"] === "string" && auth["displayName"]) ||
    (typeof auth["name"] === "string" && auth["name"]) ||
    userId;
  return { userId, displayName: displayName as string };
}

/**
 * Point the management client at this event's callback endpoint. Must be called
 * once at the top of any handler that sends messages back to clients.
 */
export function bindEndpoint(event: APIGatewayProxyWebsocketEventV2): void {
  const { domainName, stage } = event.requestContext;
  setApigwEndpoint(endpointFromContext(domainName, stage));
}

/** Send one server message to the caller's own connection. */
export async function reply(
  event: APIGatewayProxyWebsocketEventV2,
  msg: ServerMessage,
): Promise<void> {
  await postToConnection(connId(event), msg);
}

/** Send an error message back to the caller. */
export async function replyError(
  event: APIGatewayProxyWebsocketEventV2,
  code: ErrorCode,
  message: string,
): Promise<void> {
  await reply(event, { type: "error", code, message });
}
