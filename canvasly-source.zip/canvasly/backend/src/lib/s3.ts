// S3 helpers: presigned GET for snapshot download, PUT object for compaction.

import {
  S3Client,
  GetObjectCommand,
  PutObjectCommand,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { env } from "./env.js";

let s3client: S3Client | undefined;

export function s3(): S3Client {
  if (!s3client) s3client = new S3Client({});
  return s3client;
}

/** Test seam: inject a mock S3 client. */
export function __setS3ForTests(c: S3Client | undefined): void {
  s3client = c;
}

/** Presign a GET URL for a snapshot object so the client can download it. */
export async function presignSnapshotGet(s3Key: string): Promise<string> {
  return getSignedUrl(
    s3(),
    new GetObjectCommand({ Bucket: env.SNAPSHOTS_BUCKET, Key: s3Key }),
    { expiresIn: env.SNAPSHOT_URL_TTL_SECONDS },
  );
}

/** Write a snapshot blob to S3. Returns the key written. */
export async function putSnapshot(
  s3Key: string,
  body: Uint8Array,
): Promise<string> {
  await s3().send(
    new PutObjectCommand({
      Bucket: env.SNAPSHOTS_BUCKET,
      Key: s3Key,
      Body: body,
      ContentType: "application/octet-stream",
    }),
  );
  return s3Key;
}

/** Deterministic snapshot key for a board version. */
export function snapshotKey(boardId: string, version: number): string {
  return `snapshots/${boardId}/v${version}.bin`;
}
