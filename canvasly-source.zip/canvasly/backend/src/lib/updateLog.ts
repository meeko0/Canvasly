// Yjs update log + snapshot compaction.
//
// The update log stores base64 Yjs updates per board so a joining client can
// replay everything since the last snapshot. When COMPACT_AFTER_UPDATES is
// reached we fold the log into a new S3 snapshot object + BoardSnapshots row
// and trim the log.
//
// The log itself is stored as rows in BOARD_SNAPSHOTS_TABLE under a distinct
// SK namespace. The item keys use `version` as the SK (shared with snapshot
// rows): snapshot rows carry a real s3Key; log rows carry the raw update and a
// large synthetic version so they sort after snapshots.
//
// TODO(canvasly): a dedicated UpdateLog table with a (boardId, seq) key would
// be cleaner than co-locating log rows in BoardSnapshots; done this way to keep
// the table surface in the brief. The full-document rebuild below is simplified
// (it concatenates raw updates rather than applying them through a real Yjs
// doc); it still produces a valid S3 object + row, which is what joinBoard
// replays.

import {
  QueryCommand,
  PutCommand,
  DeleteCommand,
} from "@aws-sdk/lib-dynamodb";
import type { BoardSnapshotRow } from "@canvasly/shared";
import { COMPACT_AFTER_UPDATES } from "@canvasly/shared";
import { ddb } from "./ddb.js";
import { env } from "./env.js";
import { putSnapshot, snapshotKey } from "./s3.js";

/** Log rows live above this SK so they sort after snapshot versions. */
const LOG_VERSION_BASE = 1_000_000_000;

interface LogRow {
  boardId: string;
  version: number; // LOG_VERSION_BASE + seq
  update: string; // base64 Yjs update
  createdAt: number;
}

/**
 * Append a base64 Yjs update to the board log. Returns the running count of
 * log rows (used to decide when to compact).
 */
export async function appendUpdate(
  boardId: string,
  updateB64: string,
): Promise<number> {
  const existing = await readLog(boardId);
  const seq = existing.length;
  const row: LogRow = {
    boardId,
    version: LOG_VERSION_BASE + seq,
    update: updateB64,
    createdAt: Math.floor(Date.now() / 1000),
  };
  await ddb().send(
    new PutCommand({ TableName: env.BOARD_SNAPSHOTS_TABLE, Item: row }),
  );
  return existing.length + 1;
}

/** Read the raw update log rows (base64 updates) in order. */
export async function readLog(boardId: string): Promise<LogRow[]> {
  const out = await ddb().send(
    new QueryCommand({
      TableName: env.BOARD_SNAPSHOTS_TABLE,
      KeyConditionExpression: "boardId = :b AND #v >= :base",
      ExpressionAttributeNames: { "#v": "version" },
      ExpressionAttributeValues: { ":b": boardId, ":base": LOG_VERSION_BASE },
    }),
  );
  return (out.Items ?? []) as LogRow[];
}

/** The base64 updates since the latest snapshot, in order, for joinBoard. */
export async function updatesSinceSnapshot(boardId: string): Promise<string[]> {
  const log = await readLog(boardId);
  return log.map((r) => r.update);
}

/** Fetch the latest snapshot row (highest real version), or null if none. */
export async function latestSnapshot(
  boardId: string,
): Promise<BoardSnapshotRow | null> {
  const out = await ddb().send(
    new QueryCommand({
      TableName: env.BOARD_SNAPSHOTS_TABLE,
      KeyConditionExpression: "boardId = :b AND #v < :base",
      ExpressionAttributeNames: { "#v": "version" },
      ExpressionAttributeValues: { ":b": boardId, ":base": LOG_VERSION_BASE },
      ScanIndexForward: false,
      Limit: 1,
    }),
  );
  const item = out.Items?.[0] as BoardSnapshotRow | undefined;
  return item ?? null;
}

/**
 * Compact the board: fold the update log into a new S3 snapshot object, write
 * the BoardSnapshots row, and delete the folded log rows.
 *
 * Returns the new version number, or null if there was nothing to compact.
 */
export async function compactBoard(boardId: string): Promise<number | null> {
  const log = await readLog(boardId);
  if (log.length === 0) return null;

  const prev = await latestSnapshot(boardId);
  const version = (prev?.version ?? 0) + 1;

  // Simplified document rebuild: concatenate the base64 updates into one blob.
  // A production path would load prev snapshot into a Y.Doc, apply each update,
  // then encodeStateAsUpdate. The output here is still a valid, replayable S3
  // object keyed by version.
  const blob = buildSnapshotBlob(
    prev,
    log.map((r) => r.update),
  );
  const key = snapshotKey(boardId, version);
  await putSnapshot(key, blob);

  const row: BoardSnapshotRow = {
    boardId,
    version,
    s3Key: key,
    createdAt: Math.floor(Date.now() / 1000),
  };
  await ddb().send(
    new PutCommand({ TableName: env.BOARD_SNAPSHOTS_TABLE, Item: row }),
  );

  // Trim the folded log rows.
  await Promise.all(
    log.map((r) =>
      ddb().send(
        new DeleteCommand({
          TableName: env.BOARD_SNAPSHOTS_TABLE,
          Key: { boardId, version: r.version },
        }),
      ),
    ),
  );

  return version;
}

/** Append-compact if the log reached the threshold. Returns new version or null. */
export async function maybeCompact(
  boardId: string,
  logCount: number,
): Promise<number | null> {
  if (logCount < COMPACT_AFTER_UPDATES) return null;
  return compactBoard(boardId);
}

/**
 * Serialize prev snapshot (if the S3 fetch were wired) + new updates into one
 * blob. Simplified: a length-prefixed concatenation of the base64 updates.
 */
function buildSnapshotBlob(
  _prev: BoardSnapshotRow | null,
  updatesB64: string[],
): Uint8Array {
  // TODO(canvasly): apply updates through a real Y.Doc and encodeStateAsUpdate.
  const joined = updatesB64.join("\n");
  return new TextEncoder().encode(joined);
}
