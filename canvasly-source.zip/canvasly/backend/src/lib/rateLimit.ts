// Per-connection token-bucket rate limiter.
//
// In-memory per warm Lambda container. This is a best-effort guard against a
// single misbehaving connection flooding syncUpdate/cursorMove. Because Lambda
// containers are not shared across concurrent executions, a connection pinned
// to different containers could momentarily exceed the limit.
//
// TODO(canvasly): move the bucket state to a DynamoDB (or ElastiCache) counter
// keyed by connectionId so the limit is enforced globally, not per-container.

interface Bucket {
  tokens: number;
  last: number; // epoch ms of last refill
}

const buckets = new Map<string, Bucket>();

export interface RateLimitOptions {
  /** Max burst (bucket capacity). */
  capacity: number;
  /** Tokens added per second. */
  refillPerSec: number;
}

const DEFAULTS: RateLimitOptions = { capacity: 40, refillPerSec: 25 };

/**
 * Consume one token for `connectionId`. Returns true if allowed, false if the
 * bucket is empty (caller should reject with RATE_LIMITED).
 */
export function allow(
  connectionId: string,
  opts: RateLimitOptions = DEFAULTS,
  now: number = Date.now(),
): boolean {
  let b = buckets.get(connectionId);
  if (!b) {
    b = { tokens: opts.capacity, last: now };
    buckets.set(connectionId, b);
  }
  const elapsedSec = (now - b.last) / 1000;
  if (elapsedSec > 0) {
    b.tokens = Math.min(opts.capacity, b.tokens + elapsedSec * opts.refillPerSec);
    b.last = now;
  }
  if (b.tokens >= 1) {
    b.tokens -= 1;
    return true;
  }
  return false;
}

/** Drop a connection's bucket on disconnect so the map does not grow forever. */
export function forget(connectionId: string): void {
  buckets.delete(connectionId);
}

/** Test seam: clear all buckets. */
export function __resetRateLimits(): void {
  buckets.clear();
}
