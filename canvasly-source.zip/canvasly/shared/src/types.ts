/** DynamoDB entity shapes, shared across backend and frontend. */
import type { Role } from "./protocol.js";

export interface ConnectionRow {
  connectionId: string; // PK
  boardId: string; // GSI PK (query all connections on a board)
  userId: string;
  displayName: string;
  color: string;
  connectedAt: number; // epoch seconds
  ttl: number; // epoch seconds; DynamoDB TTL cleans stale rows
}

export interface BoardRow {
  boardId: string; // PK
  ownerId: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  thumbnailS3Key?: string;
}

export interface BoardMemberRow {
  boardId: string; // PK
  userId: string; // SK
  role: Role;
}

export interface BoardSnapshotRow {
  boardId: string; // PK
  version: number; // SK (monotonic)
  s3Key: string;
  createdAt: number;
}

export * from "./protocol.js";
