/**
 * Canvasly WebSocket protocol — the single source of truth for every message
 * that crosses the wire. Both `backend` and `frontend` import from here, so a
 * change to a message shape is a compile error on both sides.
 *
 * Wire format: JSON `{ "action": <route>, ...payload }`. The `action` field is
 * what API Gateway routes on (see the route selection expression in the CDK).
 */

/** Board permission roles, highest to lowest. */
export type Role = "owner" | "editor" | "viewer";

/** Client -> server routes (API Gateway WebSocket route keys). */
export type ClientAction =
  | "joinBoard"
  | "leaveBoard"
  | "syncUpdate"
  | "cursorMove"
  | "presence"
  | "ping";

/** Server -> client message types (delivered over the same socket). */
export type ServerMessageType =
  | "joined" // ack of joinBoard: here is the snapshot + updates-since
  | "userJoined"
  | "userLeft"
  | "syncUpdate" // a Yjs update from another client
  | "cursorMove"
  | "presence"
  | "pong"
  | "error";

// ---------------------------------------------------------------------------
// Client -> server
// ---------------------------------------------------------------------------

export interface JoinBoardMsg {
  action: "joinBoard";
  boardId: string;
}

export interface LeaveBoardMsg {
  action: "leaveBoard";
  boardId: string;
}

/**
 * A Yjs document update, base64-encoded. Server broadcasts to every other
 * connection on the same board and appends to the update log for compaction.
 * Rejected server-side if the sender's role is "viewer".
 */
export interface SyncUpdateMsg {
  action: "syncUpdate";
  boardId: string;
  /** base64(Uint8Array) of a Yjs update. */
  update: string;
}

/** Ephemeral cursor position. Broadcast only, never persisted. */
export interface CursorMoveMsg {
  action: "cursorMove";
  boardId: string;
  x: number;
  y: number;
}

/** Ephemeral selection / presence (which objects the user has selected). */
export interface PresenceMsg {
  action: "presence";
  boardId: string;
  selectedIds: string[];
}

/** Keeps the API Gateway connection from hitting the idle timeout. */
export interface PingMsg {
  action: "ping";
}

export type ClientMessage =
  | JoinBoardMsg
  | LeaveBoardMsg
  | SyncUpdateMsg
  | CursorMoveMsg
  | PresenceMsg
  | PingMsg;

// ---------------------------------------------------------------------------
// Server -> client
// ---------------------------------------------------------------------------

/** A peer on the same board (used in joined/userJoined/presence). */
export interface Peer {
  userId: string;
  connectionId: string;
  displayName: string;
  /** Hex color assigned to this user for cursors/selection outlines. */
  color: string;
}

export interface JoinedMsg {
  type: "joined";
  boardId: string;
  /** Presigned S3 URL to the latest compressed Yjs snapshot, or null if none. */
  snapshotUrl: string | null;
  /** base64 Yjs updates applied since the snapshot was taken, in order. */
  updatesSinceSnapshot: string[];
  /** Everyone already on the board (not including the joiner). */
  peers: Peer[];
  /** The role the server granted this connection on this board. */
  role: Role;
}

export interface UserJoinedMsg {
  type: "userJoined";
  peer: Peer;
}

export interface UserLeftMsg {
  type: "userLeft";
  connectionId: string;
  userId: string;
}

export interface SyncUpdateBroadcast {
  type: "syncUpdate";
  /** base64 Yjs update from a peer. */
  update: string;
  from: string; // connectionId
}

export interface CursorMoveBroadcast {
  type: "cursorMove";
  connectionId: string;
  userId: string;
  x: number;
  y: number;
}

export interface PresenceBroadcast {
  type: "presence";
  connectionId: string;
  userId: string;
  selectedIds: string[];
}

export interface PongMsg {
  type: "pong";
}

/** Error codes the server may return over the socket. */
export type ErrorCode =
  | "UNAUTHORIZED" // bad/missing JWT at $connect
  | "FORBIDDEN" // not a member of the board / viewer tried to write
  | "NOT_FOUND" // board does not exist
  | "RATE_LIMITED" // too many messages on this connection
  | "BAD_REQUEST" // malformed message
  | "INTERNAL";

export interface ErrorMsg {
  type: "error";
  code: ErrorCode;
  message: string;
}

export type ServerMessage =
  | JoinedMsg
  | UserJoinedMsg
  | UserLeftMsg
  | SyncUpdateBroadcast
  | CursorMoveBroadcast
  | PresenceBroadcast
  | PongMsg
  | ErrorMsg;

// ---------------------------------------------------------------------------
// Compaction policy (shared so client throttle + server compaction agree)
// ---------------------------------------------------------------------------

export const COMPACT_AFTER_UPDATES = 50;
export const COMPACT_AFTER_IDLE_MS = 30_000;
export const CURSOR_THROTTLE_HZ = 20;
export const PING_INTERVAL_MS = 5 * 60_000;
export const HARD_CLOSE_MS = 2 * 60 * 60_000;

/** Max bytes for a single WebSocket frame payload (API GW limit is 128 KiB). */
export const MAX_WS_PAYLOAD_BYTES = 120_000;
