# Deploying the Canvasly backend (so real auth + live sync work)

This provisions Cognito, DynamoDB, S3 and the WebSocket API in **your** AWS
account, then points the frontend at it. The frontend already runs in dev
no-auth mode without any of this; follow these steps when you want real
sign-in and multi-user sync.

> Everything here runs on your machine against your account and bills you.
> Nothing in this repo deploys automatically.

## 0. Prerequisites

- AWS credentials in your terminal: `aws configure` (or `aws sso login`), then
  confirm with `aws sts get-caller-identity`.
- Pick a region, e.g. `export AWS_REGION=us-east-1`.
- Node 20+ and the repo installed: from `canvasly/`, run `npm install`.

## 1. Build the workspace

```bash
cd canvasly
npm run build -w shared     # the contract the backend imports
```

The CDK bundles the backend handlers itself (esbuild via `NodejsFunction`), so
you do not pre-build `backend/`.

## 2. Bootstrap CDK (once per account+region)

```bash
cd infra
npx cdk bootstrap aws://$(aws sts get-caller-identity --query Account --output text)/${AWS_REGION}
```

This creates the small CDK staging stack (an S3 bucket + roles). Safe to re-run.

## 3. Deploy the dev stack

```bash
# still in canvasly/infra
npx cdk deploy -c env=dev
```

Review the IAM/resource summary it prints, then approve. On success it writes
outputs to `infra/cdk-outputs.json` and prints them:

- `WebSocketURL`    — e.g. `wss://abc123.execute-api.us-east-1.amazonaws.com/dev`
- `UserPoolId`      — e.g. `us-east-1_AbC123xyz`
- `UserPoolClientId`— e.g. `1h2j3k4l5m6n7o8p9q0r`
- `SnapshotsBucket` — the private snapshots bucket name

## 4. Create a test user

Email/password sign-in needs a confirmed user in the pool. Create one and set a
permanent password (no forced reset):

```bash
POOL=$(jq -r '."Canvasly-dev".UserPoolId' infra/cdk-outputs.json)

aws cognito-idp admin-create-user \
  --user-pool-id "$POOL" \
  --username you@example.com \
  --message-action SUPPRESS \
  --user-attributes Name=email,Value=you@example.com Name=email_verified,Value=true

aws cognito-idp admin-set-user-password \
  --user-pool-id "$POOL" \
  --username you@example.com \
  --password 'Str0ng!Passw0rd' \
  --permanent
```

## 5. Point the frontend at the stack

Put the outputs into `frontend/.env` (non-empty Cognito values switch off dev
no-auth mode automatically):

```bash
cd ..
cat > frontend/.env <<EOF
VITE_WS_URL=$(jq -r '."Canvasly-dev".WebSocketURL' infra/cdk-outputs.json)
VITE_COGNITO_USER_POOL_ID=$(jq -r '."Canvasly-dev".UserPoolId' infra/cdk-outputs.json)
VITE_COGNITO_CLIENT_ID=$(jq -r '."Canvasly-dev".UserPoolClientId' infra/cdk-outputs.json)
VITE_AWS_REGION=${AWS_REGION:-us-east-1}
EOF
```

## 6. Run it against the real backend

```bash
npm run dev -w frontend
```

Open the printed `http://127.0.0.1:5173/`. The "DEV · no auth" badge is gone.
Sign in with the user from step 4. The connection-status indicator goes
**connected**; open the same board in a second window to see live cursors and
sync.

## 7. (Optional) seed a board so joinBoard succeeds

`joinBoard` checks membership. Insert a board + an owner membership row for your
user (`sub`). Get your `sub`:

```bash
aws cognito-idp admin-get-user --user-pool-id "$POOL" --username you@example.com \
  --query 'UserAttributes[?Name==`sub`].Value' --output text
```

Then write the rows (replace table names from the stack — `canvasly-dev-boards`,
`canvasly-dev-board-members`):

```bash
aws dynamodb put-item --table-name canvasly-dev-boards --item '{
  "boardId":{"S":"demo-board"},"ownerId":{"S":"<your-sub>"},
  "title":{"S":"Demo"},"createdAt":{"N":"0"},"updatedAt":{"N":"0"}}'

aws dynamodb put-item --table-name canvasly-dev-board-members --item '{
  "boardId":{"S":"demo-board"},"userId":{"S":"<your-sub>"},"role":{"S":"owner"}}'
```

## 8. (Optional) Google sign-in

Supply Google OAuth credentials at deploy time; without them the Google IdP is
skipped and the default synth stays valid:

```bash
npx cdk deploy -c env=dev \
  -c googleClientId=xxxx.apps.googleusercontent.com \
  -c googleClientSecret=yyyy
```

You must also configure a Cognito Hosted UI domain + callback URLs and wire the
frontend's `signInWithGoogle()` (currently a stub). See the TODO in
`frontend/src/lib/auth/cognito.ts`.

## Prod

Same flow with `-c env=prod` — a separate stack (`Canvasly-prod`) with its own
tables, bucket and Cognito pool. Nothing is shared with dev.

## Tear down (stop billing)

```bash
cd infra
npx cdk destroy -c env=dev
```

The snapshots bucket may need emptying first if it is not empty
(`aws s3 rm s3://<SnapshotsBucket> --recursive`).

## Troubleshooting

- **Sign-in fails `NEW_PASSWORD_REQUIRED`** — you skipped the `--permanent`
  password in step 4.
- **Connects then immediately closes** — the `$connect` authorizer rejected the
  JWT. Check `VITE_COGNITO_*` match the deployed pool and that you signed in
  (the client sends the id token as `?token=`).
- **`joinBoard` returns FORBIDDEN** — no membership row; do step 7.
- **Stack name** — outputs are keyed by stack name in `cdk-outputs.json`
  (`Canvasly-dev` / `Canvasly-prod`); the `jq` paths above assume dev.
