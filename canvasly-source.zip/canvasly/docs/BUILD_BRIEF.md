# Canvasly build brief (read fully before writing)

Monorepo root: `/home/participant/.kiro/crew/workspace/canvasly`
Node 22, npm workspaces, TypeScript 5.6, strict mode, ES modules.

## Source of truth — DO NOT redefine
`shared/src/protocol.ts` and `shared/src/types.ts` are DONE and compiled.
Import everything cross-cutting from `@canvasly/shared`. Do NOT re-declare
message shapes, Role, entity rows, or the constants (COMPACT_AFTER_UPDATES,
CURSOR_THROTTLE_HZ, PING_INTERVAL_MS, HARD_CLOSE_MS, MAX_WS_PAYLOAD_BYTES).
If you need a new shared type, note it in your final report instead of
inventing a duplicate.

## Goal
Full scaffold with stubs EVERYWHERE, PLUS a real working vertical slice on the
core path: auth -> WebSocket connect -> joinBoard -> draw -> syncUpdate (Yjs)
-> live cursors -> periodic S3 snapshot. Non-slice features are stub files
with a one-line doc comment and a `// TODO(canvasly):` marker describing what
goes there. Stubs must still TYPE-CHECK (export something, no dangling refs).

## Conventions
- `.js` extension in relative imports (ESM + bundler/NodeNext resolution).
- No secrets in code. Config via env.
- Every file starts with a one-line comment saying what it is.
- Prefer small, named exports over default exports.
- Keep it compiling: a stub that breaks `tsc` is worse than no stub.

## Resource names (agree across packages)
DynamoDB tables (CDK creates, backend reads env for names):
  CONNECTIONS_TABLE, BOARDS_TABLE, BOARD_MEMBERS_TABLE, BOARD_SNAPSHOTS_TABLE
S3 bucket env: SNAPSHOTS_BUCKET
Connections table GSI name: "byBoard" (PK boardId) to list a board's connections.
WebSocket route selection expression: "$request.body.action".

Report back: what you created, what compiles, what is stubbed vs real,
and any contract gap you hit.
