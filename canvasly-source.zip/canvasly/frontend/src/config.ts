// Runtime configuration sourced from Vite env vars (see .env.example).

export const config = {
  wsUrl: import.meta.env.VITE_WS_URL ?? "",
  cognito: {
    userPoolId: import.meta.env.VITE_COGNITO_USER_POOL_ID ?? "",
    clientId: import.meta.env.VITE_COGNITO_CLIENT_ID ?? "",
    region: import.meta.env.VITE_AWS_REGION ?? "us-east-1",
  },
} as const;
