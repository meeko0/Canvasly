// Hook: owns the WebSocketClient + BoardSession lifecycle for one board, and
// mirrors connection/peers/cursors/role into the zustand store.
import { useEffect, useState } from "react";
import { config } from "../config.js";
import { getIdToken } from "../lib/auth/cognito.js";
import {
  WebSocketClient,
  type ConnectionState,
} from "../lib/ws/WebSocketClient.js";
import { BoardSession } from "../lib/yjs/BoardSession.js";
import { useBoardStore } from "../store/useBoardStore.js";

export function useBoardSession(boardId: string): {
  session: BoardSession | null;
} {
  const [session, setSession] = useState<BoardSession | null>(null);

  const setConnection = useBoardStore((s) => s.setConnection);
  const setPeers = useBoardStore((s) => s.setPeers);
  const setRole = useBoardStore((s) => s.setRole);
  const upsertCursor = useBoardStore((s) => s.upsertCursor);
  const removeCursor = useBoardStore((s) => s.removeCursor);
  const bumpShapes = useBoardStore((s) => s.bumpShapes);

  useEffect(() => {
    let sess: BoardSession | null = null;

    const handleState = (state: ConnectionState) => {
      setConnection(state);
      // (Re)join the board on every successful (re)connect. join() queues if
      // the socket flaps, and the client flushes the queue on open.
      if (state === "open" && sess) sess.join();
    };

    const ws = new WebSocketClient({
      url: config.wsUrl,
      getToken: getIdToken,
      onStateChange: handleState,
    });

    sess = new BoardSession(ws, boardId, {
      onPeersChanged: setPeers,
      onRole: setRole,
      onCursor: upsertCursor,
      onCursorLeft: removeCursor,
      onShapesChanged: bumpShapes,
    });

    ws.connect();
    sess.join(); // queued until the socket is open, then flushed.
    setSession(sess);

    return () => {
      sess?.leave();
      sess?.destroy();
      ws.disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [boardId]);

  return { session };
}
