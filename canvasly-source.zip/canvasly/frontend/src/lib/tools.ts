// Typed stubs for deferred drawing tools and editing operations. These define
// the intended contracts (so the toolbar/canvas can wire them later) without
// implementing behavior. Each is a no-op or throws with a TODO marker.
import type { Shape } from "./yjs/doc.js";
import type { BoardSession } from "./yjs/BoardSession.js";

export interface Point {
  x: number;
  y: number;
}

// --- deferred shape tools -------------------------------------------------

// TODO(canvasly): sticky-note tool — fixed-size colored card with editable text.
export function createSticky(_at: Point, _color: string): Shape {
  throw new Error("TODO(canvasly): sticky notes not implemented");
}

// TODO(canvasly): text tool — click to place an editable text node.
export function createText(_at: Point, _text: string): Shape {
  throw new Error("TODO(canvasly): text tool not implemented");
}

// TODO(canvasly): ellipse / line / arrow geometry tools.
export function createEllipse(_from: Point, _to: Point): Shape {
  throw new Error("TODO(canvasly): ellipse not implemented");
}
export function createLine(_from: Point, _to: Point): Shape {
  throw new Error("TODO(canvasly): line not implemented");
}
export function createArrow(_from: Point, _to: Point): Shape {
  throw new Error("TODO(canvasly): arrow not implemented");
}

// TODO(canvasly): eraser — remove shapes intersecting the pointer path.
export function eraseAt(_session: BoardSession, _at: Point): void {
  /* no-op stub */
}

// TODO(canvasly): highlighter — semi-transparent wide pen stroke.
export function createHighlighter(_at: Point, _color: string): Shape {
  throw new Error("TODO(canvasly): highlighter not implemented");
}

// TODO(canvasly): image upload — put to S3 then insert an image shape.
export async function uploadImage(_file: File): Promise<string> {
  throw new Error("TODO(canvasly): image upload not implemented");
}

// --- deferred editing ops -------------------------------------------------

export interface Transform {
  x: number;
  y: number;
  rotation: number;
  scaleX: number;
  scaleY: number;
}

// TODO(canvasly): select / resize / rotate via a Konva Transformer.
export function applyTransform(
  _session: BoardSession,
  _id: string,
  _t: Transform,
): void {
  /* no-op stub */
}

// TODO(canvasly): group / ungroup selected shapes.
export function groupShapes(_session: BoardSession, _ids: string[]): string {
  throw new Error("TODO(canvasly): grouping not implemented");
}

// TODO(canvasly): snap-to-grid — round a point to the nearest grid cell.
export function snapToGrid(p: Point, _gridSize = 8): Point {
  // Returns the point unchanged until snapping is enabled.
  return p;
}
