// Export helpers (stub): PNG / SVG / PDF export of the board. Typed signatures
// so callers compile; implementations are deferred.
import type { BoardSession } from "../lib/yjs/BoardSession.js";

export type ExportFormat = "png" | "svg" | "pdf";

export interface ExportOptions {
  format: ExportFormat;
  /** Scale multiplier for raster export. */
  pixelRatio?: number;
}

// TODO(canvasly): rasterize the Konva Stage (stage.toDataURL) for PNG, serialize
// shapes to SVG, and compose a PDF (e.g. via pdf-lib). Returns a Blob to save.
export async function exportBoard(
  _session: BoardSession,
  _opts: ExportOptions,
): Promise<Blob> {
  throw new Error("TODO(canvasly): board export not implemented");
}
