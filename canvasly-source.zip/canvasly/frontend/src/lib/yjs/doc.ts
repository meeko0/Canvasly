// Yjs document wrapper: a Y.Doc with a 'shapes' Y.Map, base64 update
// encode/apply helpers, and a per-user Y.UndoManager scoped to local edits.
import * as Y from "yjs";

/** Shape kinds the vertical slice renders. Extend as tools come online. */
export type ShapeType =
  | "pen"
  | "rectangle"
  // TODO(canvasly): "ellipse" | "line" | "arrow" | "text" | "sticky" | "image"
  ;

/** A shape stored in the Yjs 'shapes' map. Kept JSON-serializable. */
export interface Shape {
  id: string;
  type: ShapeType;
  /** Owner connection/user color for authored outlines. */
  color: string;
  strokeWidth: number;
  /** Freehand points [x0,y0,x1,y1,...] for pen; corner points for rect. */
  points: number[];
  /** Rectangle geometry (unused for pen). */
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  createdBy: string;
}

export type ShapesMap = Y.Map<Shape>;

export class BoardDoc {
  readonly doc: Y.Doc;
  readonly shapes: ShapesMap;
  readonly undoManager: Y.UndoManager;

  /** Local origin tag so we can tell our own updates from remote ones. */
  readonly localOrigin = { local: true };

  constructor() {
    this.doc = new Y.Doc();
    this.shapes = this.doc.getMap<Shape>("shapes");
    // Per-user undo: only transactions tagged with our local origin are
    // tracked, so Ctrl+Z never rolls back a peer's edit.
    this.undoManager = new Y.UndoManager(this.shapes, {
      trackedOrigins: new Set([this.localOrigin]),
    });
  }

  /** Apply a local mutation under the tracked origin (so undo captures it). */
  transactLocal(fn: () => void): void {
    this.doc.transact(fn, this.localOrigin);
  }

  setShape(shape: Shape): void {
    this.transactLocal(() => this.shapes.set(shape.id, shape));
  }

  deleteShape(id: string): void {
    this.transactLocal(() => this.shapes.delete(id));
  }

  listShapes(): Shape[] {
    return Array.from(this.shapes.values());
  }

  undo(): void {
    this.undoManager.undo();
  }

  redo(): void {
    this.undoManager.redo();
  }

  destroy(): void {
    this.undoManager.destroy();
    this.doc.destroy();
  }
}

// --- base64 <-> Uint8Array (browser-safe, no Buffer) ----------------------

export function toBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

export function fromBase64(b64: string): Uint8Array {
  const binary = atob(b64);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

/** Encode the full current state as a base64 update (for snapshotting). */
export function encodeStateAsUpdate(doc: Y.Doc): string {
  return toBase64(Y.encodeStateAsUpdate(doc));
}

/** Apply a base64-encoded remote update with the given origin. */
export function applyBase64Update(
  doc: Y.Doc,
  b64: string,
  origin: unknown,
): void {
  Y.applyUpdate(doc, fromBase64(b64), origin);
}
