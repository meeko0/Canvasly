// BoardSession wires the Yjs doc to the WebSocket client for one board:
// local doc updates -> syncUpdate; incoming syncUpdate -> Y.applyUpdate; and it
// surfaces joined/userJoined/userLeft/cursorMove to the presence store.
import { CURSOR_THROTTLE_HZ, type Peer, type Role } from "@canvasly/shared";
import { WebSocketClient } from "../ws/WebSocketClient.js";
import {
  BoardDoc,
  applyBase64Update,
  fromBase64,
  toBase64,
} from "./doc.js";
import * as Y from "yjs";

export interface RemoteCursor {
  connectionId: string;
  userId: string;
  x: number;
  y: number;
}

export interface BoardSessionCallbacks {
  onPeersChanged?: (peers: Peer[]) => void;
  onCursor?: (cursor: RemoteCursor) => void;
  onCursorLeft?: (connectionId: string) => void;
  onRole?: (role: Role) => void;
  onShapesChanged?: () => void;
}

const CURSOR_MIN_INTERVAL_MS = 1000 / CURSOR_THROTTLE_HZ;

export class BoardSession {
  readonly board: BoardDoc;
  private readonly ws: WebSocketClient;
  private readonly boardId: string;
  private readonly cbs: BoardSessionCallbacks;

  /** Origin marker for remote-applied updates, so we don't echo them back. */
  private readonly remoteOrigin = { remote: true };

  private peers: Peer[] = [];
  private lastCursorSent = 0;
  private readonly unsubs: Array<() => void> = [];

  constructor(
    ws: WebSocketClient,
    boardId: string,
    cbs: BoardSessionCallbacks = {},
  ) {
    this.ws = ws;
    this.boardId = boardId;
    this.cbs = cbs;
    this.board = new BoardDoc();
    this.wire();
  }

  private wire(): void {
    // Local doc update -> broadcast. Skip updates we applied from remote.
    const onDocUpdate = (update: Uint8Array, origin: unknown) => {
      if (origin === this.remoteOrigin) return;
      this.ws.send({
        action: "syncUpdate",
        boardId: this.boardId,
        update: toBase64(update),
      });
    };
    this.board.doc.on("update", onDocUpdate);
    this.unsubs.push(() => this.board.doc.off("update", onDocUpdate));

    const shapesObserver = () => this.cbs.onShapesChanged?.();
    this.board.shapes.observeDeep(shapesObserver);
    this.unsubs.push(() =>
      this.board.shapes.unobserveDeep(shapesObserver),
    );

    // Server -> client.
    this.unsubs.push(
      this.ws.on("joined", (msg) => {
        this.peers = msg.peers;
        this.cbs.onRole?.(msg.role);
        this.cbs.onPeersChanged?.(this.peers);
        // Apply any updates accumulated since the snapshot, in order.
        for (const u of msg.updatesSinceSnapshot) {
          applyBase64Update(this.board.doc, u, this.remoteOrigin);
        }
        // TODO(canvasly): fetch msg.snapshotUrl (presigned S3) and
        // Y.applyUpdate the decompressed snapshot before the delta updates.
        if (msg.snapshotUrl) void this.loadSnapshot(msg.snapshotUrl);
      }),
    );

    this.unsubs.push(
      this.ws.on("userJoined", (msg) => {
        if (!this.peers.some((p) => p.connectionId === msg.peer.connectionId)) {
          this.peers = [...this.peers, msg.peer];
          this.cbs.onPeersChanged?.(this.peers);
        }
      }),
    );

    this.unsubs.push(
      this.ws.on("userLeft", (msg) => {
        this.peers = this.peers.filter(
          (p) => p.connectionId !== msg.connectionId,
        );
        this.cbs.onPeersChanged?.(this.peers);
        this.cbs.onCursorLeft?.(msg.connectionId);
      }),
    );

    this.unsubs.push(
      this.ws.on("syncUpdate", (msg) => {
        applyBase64Update(this.board.doc, msg.update, this.remoteOrigin);
      }),
    );

    this.unsubs.push(
      this.ws.on("cursorMove", (msg) => {
        this.cbs.onCursor?.({
          connectionId: msg.connectionId,
          userId: msg.userId,
          x: msg.x,
          y: msg.y,
        });
      }),
    );
  }

  /** Call after the socket is open to join and request state. */
  join(): void {
    this.ws.send({ action: "joinBoard", boardId: this.boardId });
  }

  leave(): void {
    this.ws.send({ action: "leaveBoard", boardId: this.boardId });
  }

  /** Throttled cursor broadcast at CURSOR_THROTTLE_HZ. */
  sendCursor(x: number, y: number): void {
    const now = Date.now();
    if (now - this.lastCursorSent < CURSOR_MIN_INTERVAL_MS) return;
    this.lastCursorSent = now;
    this.ws.send({ action: "cursorMove", boardId: this.boardId, x, y });
  }

  getPeers(): Peer[] {
    return this.peers;
  }

  private async loadSnapshot(url: string): Promise<void> {
    try {
      const res = await fetch(url);
      if (!res.ok) return;
      const buf = new Uint8Array(await res.arrayBuffer());
      // Snapshot is a raw/compressed Yjs state update. If the backend
      // base64-wraps it this will change; keep in sync with the backend.
      Y.applyUpdate(this.board.doc, buf, this.remoteOrigin);
    } catch {
      // Best-effort: delta updates in `joined` still bring us up to date.
    }
  }

  destroy(): void {
    for (const u of this.unsubs) u();
    this.unsubs.length = 0;
    this.board.destroy();
  }
}

// Re-export for callers that only need the base64 helper.
export { fromBase64 };
