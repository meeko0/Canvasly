// Real Cognito auth via @aws-amplify/auth: configure the pool, email/password
// sign-in, sign-out, and getIdToken() (the JWT the WS client sends as ?token).
import { Amplify } from "aws-amplify";
import {
  signIn as amplifySignIn,
  signOut as amplifySignOut,
  fetchAuthSession,
  getCurrentUser,
} from "@aws-amplify/auth";
import { config } from "../../config.js";

let configured = false;

/**
 * True when no Cognito pool is configured (env vars empty). The app then runs
 * in DEV / no-auth mode: Amplify is never configured (it throws on an empty
 * pool id), and a local mock user lets you load the whiteboard before the CDK
 * stack is deployed. Set VITE_COGNITO_* in .env to use real auth.
 */
export const DEV_NO_AUTH =
  !config.cognito.userPoolId || !config.cognito.clientId;

const DEV_USER: AuthUser = {
  userId: "dev-user",
  username: "dev@canvasly.local",
};

/** Configure Amplify from env. Safe to call more than once. */
export function configureAuth(): void {
  if (configured || DEV_NO_AUTH) return;
  Amplify.configure({
    Auth: {
      Cognito: {
        userPoolId: config.cognito.userPoolId,
        userPoolClientId: config.cognito.clientId,
      },
    },
  });
  configured = true;
}

export interface AuthUser {
  userId: string;
  username: string;
}

/** Email/password sign-in. Resolves once the session is established. */
export async function signInWithPassword(
  email: string,
  password: string,
): Promise<AuthUser> {
  if (DEV_NO_AUTH) {
    // No pool configured — accept any credentials locally.
    return { ...DEV_USER, username: email || DEV_USER.username };
  }
  configureAuth();
  const res = await amplifySignIn({ username: email, password });
  if (!res.isSignedIn) {
    // e.g. NEW_PASSWORD_REQUIRED / MFA — surfaced to the caller to handle.
    throw new Error(`Sign-in incomplete: ${res.nextStep.signInStep}`);
  }
  return currentUser();
}

export async function currentUser(): Promise<AuthUser> {
  if (DEV_NO_AUTH) return DEV_USER;
  configureAuth();
  const u = await getCurrentUser();
  return { userId: u.userId, username: u.username };
}

/** Returns the Cognito ID token (JWT). Throws if not signed in. */
export async function getIdToken(): Promise<string> {
  if (DEV_NO_AUTH) {
    // A placeholder token; a real deployed $connect authorizer would reject it.
    // The local dev server has no backend to validate against anyway.
    return "DEV_NO_AUTH_TOKEN";
  }
  configureAuth();
  const session = await fetchAuthSession();
  const token = session.tokens?.idToken?.toString();
  if (!token) throw new Error("No ID token; user is not authenticated.");
  return token;
}

export async function signOut(): Promise<void> {
  if (DEV_NO_AUTH) return;
  configureAuth();
  await amplifySignOut();
}

// TODO(canvasly): signInWithGoogle() via Cognito Hosted UI / federated OAuth.
// TODO(canvasly): resetPassword() + confirmResetPassword() flows.
