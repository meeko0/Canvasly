// Typed WebSocket client: connects with a Cognito JWT, sends ClientMessage,
// dispatches ServerMessage by type, auto-reconnects with exponential backoff,
// pings on PING_INTERVAL_MS, and queues outgoing messages while offline.
import {
  PING_INTERVAL_MS,
  type ClientMessage,
  type ServerMessage,
  type ServerMessageType,
} from "@canvasly/shared";

/** A handler for one server message type. */
type Handler<T extends ServerMessageType> = (
  msg: Extract<ServerMessage, { type: T }>,
) => void;

export type ConnectionState =
  | "idle"
  | "connecting"
  | "open"
  | "closed"
  | "reconnecting";

export interface WebSocketClientOptions {
  /** Base WS URL, e.g. wss://xxx.execute-api.region.amazonaws.com/prod */
  url: string;
  /** Returns a fresh Cognito ID token (JWT) for the `token` query param. */
  getToken: () => Promise<string>;
  /** Called whenever the connection state changes (for the status indicator). */
  onStateChange?: (state: ConnectionState) => void;
  /** Max backoff delay in ms (default 30s). */
  maxBackoffMs?: number;
}

export class WebSocketClient {
  private ws: WebSocket | null = null;
  private readonly url: string;
  private readonly getToken: () => Promise<string>;
  private readonly onStateChange?: (state: ConnectionState) => void;
  private readonly maxBackoffMs: number;

  private state: ConnectionState = "idle";
  private attempts = 0;
  private wantOpen = false;
  private pingTimer: ReturnType<typeof setInterval> | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;

  /** Outgoing messages buffered while the socket is down. */
  private readonly outbox: ClientMessage[] = [];

  /** Per-type listener sets. */
  private readonly handlers = new Map<ServerMessageType, Set<Handler<any>>>();

  constructor(opts: WebSocketClientOptions) {
    this.url = opts.url;
    this.getToken = opts.getToken;
    this.onStateChange = opts.onStateChange;
    this.maxBackoffMs = opts.maxBackoffMs ?? 30_000;
  }

  getState(): ConnectionState {
    return this.state;
  }

  /** Subscribe to a server message type. Returns an unsubscribe function. */
  on<T extends ServerMessageType>(type: T, handler: Handler<T>): () => void {
    let set = this.handlers.get(type);
    if (!set) {
      set = new Set();
      this.handlers.set(type, set);
    }
    set.add(handler);
    return () => set!.delete(handler);
  }

  /** Open the connection (idempotent). */
  connect(): void {
    this.wantOpen = true;
    if (this.ws && (this.state === "open" || this.state === "connecting")) {
      return;
    }
    void this.openSocket();
  }

  /** Close the connection permanently; stops reconnection. */
  disconnect(): void {
    this.wantOpen = false;
    this.clearTimers();
    if (this.ws) {
      try {
        this.ws.close(1000, "client disconnect");
      } catch {
        /* ignore */
      }
      this.ws = null;
    }
    this.setState("closed");
  }

  /** Send a message, or queue it if the socket is not open. */
  send(msg: ClientMessage): void {
    if (this.ws && this.state === "open") {
      try {
        this.ws.send(JSON.stringify(msg));
        return;
      } catch {
        // fall through to queue on failure
      }
    }
    this.outbox.push(msg);
  }

  private async openSocket(): Promise<void> {
    // No URL configured (dev no-backend mode): stay offline silently. Local
    // Yjs editing still works; there is just no remote sync to connect to.
    if (!this.url) {
      this.setState("closed");
      return;
    }
    this.setState(this.attempts === 0 ? "connecting" : "reconnecting");
    let token = "";
    try {
      token = await this.getToken();
    } catch {
      // Could not get a token; retry via backoff.
      this.scheduleReconnect();
      return;
    }
    if (!this.wantOpen) return;

    const sep = this.url.includes("?") ? "&" : "?";
    const fullUrl = `${this.url}${sep}token=${encodeURIComponent(token)}`;

    let ws: WebSocket;
    try {
      ws = new WebSocket(fullUrl);
    } catch {
      this.scheduleReconnect();
      return;
    }
    this.ws = ws;

    ws.onopen = () => {
      this.attempts = 0;
      this.setState("open");
      this.startPing();
      this.flushOutbox();
    };

    ws.onmessage = (ev) => this.handleMessage(ev.data);

    ws.onerror = () => {
      // onclose will follow; nothing to do here.
    };

    ws.onclose = () => {
      this.stopPing();
      this.ws = null;
      if (this.wantOpen) {
        this.scheduleReconnect();
      } else {
        this.setState("closed");
      }
    };
  }

  private handleMessage(data: unknown): void {
    if (typeof data !== "string") return;
    let parsed: ServerMessage;
    try {
      parsed = JSON.parse(data) as ServerMessage;
    } catch {
      return;
    }
    if (!parsed || typeof parsed.type !== "string") return;
    const set = this.handlers.get(parsed.type);
    if (!set) return;
    for (const h of set) {
      try {
        h(parsed as any);
      } catch (err) {
        // A listener error must not kill the dispatch loop.
        console.error("[ws] handler error", err);
      }
    }
  }

  private flushOutbox(): void {
    if (!this.ws || this.state !== "open") return;
    while (this.outbox.length > 0) {
      const msg = this.outbox.shift()!;
      try {
        this.ws.send(JSON.stringify(msg));
      } catch {
        // Put it back and stop; we'll retry on the next open.
        this.outbox.unshift(msg);
        break;
      }
    }
  }

  private scheduleReconnect(): void {
    if (!this.wantOpen) return;
    this.setState("reconnecting");
    const base = Math.min(1000 * 2 ** this.attempts, this.maxBackoffMs);
    const jitter = Math.random() * 0.3 * base;
    const delay = base + jitter;
    this.attempts += 1;
    this.clearReconnectTimer();
    this.reconnectTimer = setTimeout(() => void this.openSocket(), delay);
  }

  private startPing(): void {
    this.stopPing();
    this.pingTimer = setInterval(() => {
      this.send({ action: "ping" });
    }, PING_INTERVAL_MS);
  }

  private stopPing(): void {
    if (this.pingTimer) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
  }

  private clearReconnectTimer(): void {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
  }

  private clearTimers(): void {
    this.stopPing();
    this.clearReconnectTimer();
  }

  private setState(state: ConnectionState): void {
    if (this.state === state) return;
    this.state = state;
    this.onStateChange?.(state);
  }
}
