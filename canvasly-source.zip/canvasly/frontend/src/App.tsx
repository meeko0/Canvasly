// App shell: auth gate + routing between DashboardPage and BoardPage.
import { useEffect, useState } from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import { SignIn } from "./components/auth/SignIn.js";
import { DashboardPage } from "./pages/DashboardPage.js";
import { BoardPage } from "./pages/BoardPage.js";
import { ThemeProvider } from "./theme/ThemeContext.js";
import { configureAuth, currentUser, type AuthUser } from "./lib/auth/cognito.js";

export function App() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    configureAuth();
    // Restore an existing Cognito session on load, if any.
    currentUser()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setChecking(false));
  }, []);

  if (checking) {
    return <div className="app-loading">Loading…</div>;
  }

  return (
    <ThemeProvider>
      {user ? (
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/board/:boardId" element={<BoardPage user={user} />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      ) : (
        <div className="auth-screen">
          <SignIn onSignedIn={setUser} />
        </div>
      )}
    </ThemeProvider>
  );
}
