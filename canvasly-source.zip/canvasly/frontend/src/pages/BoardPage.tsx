// BoardPage: the real collaborative editor. Owns the board session and lays
// out the canvas, toolbar, presence avatars, connection status and theme toggle.
import { useParams } from "react-router-dom";
import { useBoardSession } from "../hooks/useBoardSession.js";
import { Canvas } from "../components/canvas/Canvas.js";
import { Toolbar } from "../components/toolbar/Toolbar.js";
import { ThemeToggle } from "../components/toolbar/ThemeToggle.js";
import { AvatarStack } from "../components/presence/AvatarStack.js";
import { ConnectionStatus } from "../components/presence/ConnectionStatus.js";
import { DEV_NO_AUTH, type AuthUser } from "../lib/auth/cognito.js";

export interface BoardPageProps {
  user: AuthUser;
}

export function BoardPage({ user }: BoardPageProps) {
  const params = useParams();
  const boardId = params.boardId ?? "demo-board";
  const { session } = useBoardSession(boardId);

  return (
    <div className="board-page">
      <header className="board-topbar">
        <div className="board-title">
          Canvasly · {boardId}
          {DEV_NO_AUTH && (
            <span
              className="dev-badge"
              title="No Cognito configured — local mock user, no live sync. Set VITE_COGNITO_* in .env for real auth."
            >
              DEV · no auth
            </span>
          )}
        </div>
        <div className="board-topbar-right">
          <ConnectionStatus />
          <AvatarStack />
          <ThemeToggle />
        </div>
      </header>

      {session ? (
        <>
          <Canvas session={session} userId={user.userId} />
          <Toolbar session={session} />
        </>
      ) : (
        <div className="board-loading">Connecting to board…</div>
      )}
    </div>
  );
}
