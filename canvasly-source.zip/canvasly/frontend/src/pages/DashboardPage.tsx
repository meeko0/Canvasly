// DashboardPage: board list. STUB — renders mock boards; real wiring to a
// list-boards API / BOARDS_TABLE is deferred.
import { Link } from "react-router-dom";
import type { BoardRow } from "@canvasly/shared";

// TODO(canvasly): replace with a real fetch of the signed-in user's boards
// (GET /boards -> BOARDS_TABLE + BOARD_MEMBERS_TABLE). Mock data for now.
const MOCK_BOARDS: BoardRow[] = [
  {
    boardId: "demo-board",
    ownerId: "u-mock",
    title: "Welcome board (demo)",
    createdAt: 0,
    updatedAt: 0,
  },
  {
    boardId: "sprint-42",
    ownerId: "u-mock",
    title: "Sprint 42 planning",
    createdAt: 0,
    updatedAt: 0,
  },
];

export function DashboardPage() {
  return (
    <div className="dashboard-page">
      <header className="dashboard-topbar">
        <h1>Your boards</h1>
        {/* TODO(canvasly): "New board" creates a BoardRow and navigates to it. */}
        <button className="btn-primary" disabled title="Coming soon">
          New board
        </button>
      </header>
      <ul className="board-grid">
        {MOCK_BOARDS.map((b) => (
          <li key={b.boardId} className="board-card">
            <Link to={`/board/${b.boardId}`}>
              <span className="board-card-title">{b.title}</span>
              <span className="board-card-sub">{b.boardId}</span>
            </Link>
          </li>
        ))}
      </ul>
      <p className="dashboard-note">
        Demo data — board list is a stub. The editor at any board link is real.
      </p>
    </div>
  );
}
