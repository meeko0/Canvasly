// Global UI/session state for the board editor (zustand).
import { create } from "zustand";
import type { Peer, Role } from "@canvasly/shared";
import type { ConnectionState } from "../lib/ws/WebSocketClient.js";
import type { RemoteCursor } from "../lib/yjs/BoardSession.js";

/** Active drawing tool. 'select' is real; most others are stubbed. */
export type Tool =
  | "select"
  | "pen"
  | "rectangle"
  // TODO(canvasly): "ellipse" | "line" | "arrow" | "text" | "sticky"
  //                 | "eraser" | "highlighter" | "image"
  ;

export interface BoardStore {
  tool: Tool;
  setTool: (tool: Tool) => void;

  strokeColor: string;
  setStrokeColor: (c: string) => void;
  strokeWidth: number;
  setStrokeWidth: (w: number) => void;

  connection: ConnectionState;
  setConnection: (s: ConnectionState) => void;

  role: Role | null;
  setRole: (r: Role | null) => void;

  peers: Peer[];
  setPeers: (p: Peer[]) => void;

  cursors: Record<string, RemoteCursor>;
  upsertCursor: (c: RemoteCursor) => void;
  removeCursor: (connectionId: string) => void;

  /** Bumped whenever the Yjs shapes map changes, to force a re-render. */
  shapesVersion: number;
  bumpShapes: () => void;
}

export const useBoardStore = create<BoardStore>((set) => ({
  tool: "select",
  setTool: (tool) => set({ tool }),

  strokeColor: "#1a1a1a",
  setStrokeColor: (strokeColor) => set({ strokeColor }),
  strokeWidth: 3,
  setStrokeWidth: (strokeWidth) => set({ strokeWidth }),

  connection: "idle",
  setConnection: (connection) => set({ connection }),

  role: null,
  setRole: (role) => set({ role }),

  peers: [],
  setPeers: (peers) => set({ peers }),

  cursors: {},
  upsertCursor: (c) =>
    set((s) => ({ cursors: { ...s.cursors, [c.connectionId]: c } })),
  removeCursor: (connectionId) =>
    set((s) => {
      const next = { ...s.cursors };
      delete next[connectionId];
      return { cursors: next };
    }),

  shapesVersion: 0,
  bumpShapes: () => set((s) => ({ shapesVersion: s.shapesVersion + 1 })),
}));
