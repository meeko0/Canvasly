// Real Cognito email/password sign-in form. On success, calls onSignedIn with
// the authenticated user. Google sign-in + password reset are stub buttons.
import { useState, type FormEvent } from "react";
import {
  signInWithPassword,
  DEV_NO_AUTH,
  type AuthUser,
} from "../../lib/auth/cognito.js";

export interface SignInProps {
  onSignedIn: (user: AuthUser) => void;
}

export function SignIn({ onSignedIn }: SignInProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const user = await signInWithPassword(email, password);
      onSignedIn(user);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-card">
      <h1 className="auth-title">Canvasly</h1>
      {DEV_NO_AUTH && (
        <p className="auth-dev-note">
          Dev mode — no Cognito configured. Any email/password signs you in
          locally. Set <code>VITE_COGNITO_*</code> in <code>.env</code> for real
          auth.
        </p>
      )}
      <form onSubmit={handleSubmit} className="auth-form">
        <label className="auth-label">
          Email
          <input
            type="email"
            autoComplete="username"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </label>
        <label className="auth-label">
          Password
          <input
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </label>
        {error && <p className="auth-error">{error}</p>}
        <button type="submit" disabled={busy} className="btn-primary">
          {busy ? "Signing in…" : "Sign in"}
        </button>
      </form>

      {/* TODO(canvasly): wire real Google federated sign-in. */}
      <button
        type="button"
        className="btn-secondary"
        onClick={() => alert("Google sign-in not yet implemented")}
      >
        Continue with Google
      </button>
      {/* TODO(canvasly): wire real password-reset flow. */}
      <button
        type="button"
        className="btn-link"
        onClick={() => alert("Password reset not yet implemented")}
      >
        Forgot password?
      </button>
    </div>
  );
}
