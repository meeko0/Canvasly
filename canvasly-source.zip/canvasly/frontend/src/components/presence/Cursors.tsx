// Remote live cursors, rendered as Konva nodes inside the canvas Layer. Reads
// cursor positions (world coords) from the store, which useBoardSession fills
// from incoming cursorMove messages. Peer color comes from the peer list.
import { useMemo } from "react";
import { Group, Circle, Text } from "react-konva";
import { useBoardStore } from "../../store/useBoardStore.js";

export interface CursorsProps {
  /** Current stage scale, so cursor glyphs stay a constant screen size. */
  scale: number;
}

export function Cursors({ scale }: CursorsProps) {
  const cursors = useBoardStore((s) => s.cursors);
  const peers = useBoardStore((s) => s.peers);

  const colorByUser = useMemo(() => {
    const m = new Map<string, string>();
    for (const p of peers) m.set(p.userId, p.color);
    return m;
  }, [peers]);

  const nameByUser = useMemo(() => {
    const m = new Map<string, string>();
    for (const p of peers) m.set(p.userId, p.displayName);
    return m;
  }, [peers]);

  const inv = 1 / scale;

  return (
    <>
      {Object.values(cursors).map((c) => {
        const color = colorByUser.get(c.userId) ?? "#f43f5e";
        const name = nameByUser.get(c.userId) ?? "guest";
        return (
          <Group key={c.connectionId} x={c.x} y={c.y} listening={false}>
            <Circle radius={5 * inv} fill={color} />
            <Text
              x={8 * inv}
              y={-6 * inv}
              text={name}
              fontSize={12 * inv}
              fill={color}
            />
          </Group>
        );
      })}
    </>
  );
}
