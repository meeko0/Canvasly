// Connection-status indicator (real): reflects the WebSocket client's state
// from the store, including an offline/reconnecting badge.
import { useBoardStore } from "../../store/useBoardStore.js";
import type { ConnectionState } from "../../lib/ws/WebSocketClient.js";

const LABEL: Record<ConnectionState, string> = {
  idle: "Idle",
  connecting: "Connecting…",
  open: "Live",
  reconnecting: "Reconnecting…",
  closed: "Offline",
};

const DOT: Record<ConnectionState, string> = {
  idle: "#9ca3af",
  connecting: "#f59e0b",
  open: "#22c55e",
  reconnecting: "#f59e0b",
  closed: "#ef4444",
};

export function ConnectionStatus() {
  const state = useBoardStore((s) => s.connection);
  return (
    <div className="conn-status" title={`Connection: ${LABEL[state]}`}>
      <span className="conn-dot" style={{ background: DOT[state] }} />
      <span className="conn-label">{LABEL[state]}</span>
    </div>
  );
}
