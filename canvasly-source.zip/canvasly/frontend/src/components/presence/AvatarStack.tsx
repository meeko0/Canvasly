// AvatarStack: shows connected peers from the live presence list (real —
// driven by joined / userJoined / userLeft via the store).
import { useBoardStore } from "../../store/useBoardStore.js";
import type { Peer } from "@canvasly/shared";

function initials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return (parts[0]?.[0] ?? "?").toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function AvatarStack() {
  const peers = useBoardStore((s) => s.peers);

  return (
    <div className="avatar-stack" aria-label="Connected collaborators">
      {peers.length === 0 && (
        <span className="avatar-empty">Only you</span>
      )}
      {peers.map((p: Peer) => (
        <div
          key={p.connectionId}
          className="avatar"
          title={p.displayName}
          style={{ background: p.color }}
        >
          {initials(p.displayName)}
        </div>
      ))}
    </div>
  );
}
