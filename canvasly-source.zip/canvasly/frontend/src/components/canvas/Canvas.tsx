// Infinite-canvas editor surface (react-konva): pan + zoom, renders shapes from
// the Yjs 'shapes' map, PEN (freehand) and RECTANGLE tools write into the map,
// and it broadcasts the local cursor (throttled) + renders remote cursors.
import { useRef, useState, useMemo } from "react";
import { Stage, Layer, Line, Rect } from "react-konva";
import type Konva from "konva";
import { useBoardStore } from "../../store/useBoardStore.js";
import type { BoardSession } from "../../lib/yjs/BoardSession.js";
import type { Shape } from "../../lib/yjs/doc.js";
import { Cursors } from "../presence/Cursors.js";

export interface CanvasProps {
  session: BoardSession;
  userId: string;
}

interface Viewport {
  x: number;
  y: number;
  scale: number;
}

const SCALE_MIN = 0.1;
const SCALE_MAX = 8;

let shapeSeq = 0;
function nextId(prefix: string): string {
  shapeSeq += 1;
  return `${prefix}-${Date.now().toString(36)}-${shapeSeq}`;
}

export function Canvas({ session, userId }: CanvasProps) {
  const stageRef = useRef<Konva.Stage | null>(null);
  const [view, setView] = useState<Viewport>({ x: 0, y: 0, scale: 1 });

  const tool = useBoardStore((s) => s.tool);
  const strokeColor = useBoardStore((s) => s.strokeColor);
  const strokeWidth = useBoardStore((s) => s.strokeWidth);
  // Re-read shapes whenever the Yjs map changes.
  const shapesVersion = useBoardStore((s) => s.shapesVersion);

  // Draft shape being drawn (not yet committed every frame to Yjs).
  const drawingId = useRef<string | null>(null);
  const [draftTick, setDraftTick] = useState(0);

  const shapes: Shape[] = useMemo(
    () => session.board.listShapes(),
    // shapesVersion forces recompute on remote/local map changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [session, shapesVersion, draftTick],
  );

  /** Convert a stage pointer position to board (world) coordinates. */
  function toWorld(stage: Konva.Stage): { x: number; y: number } {
    const pos = stage.getPointerPosition();
    if (!pos) return { x: 0, y: 0 };
    return {
      x: (pos.x - view.x) / view.scale,
      y: (pos.y - view.y) / view.scale,
    };
  }

  function handleWheel(e: Konva.KonvaEventObject<WheelEvent>) {
    e.evt.preventDefault();
    const stage = stageRef.current;
    if (!stage) return;
    const pointer = stage.getPointerPosition();
    if (!pointer) return;

    const oldScale = view.scale;
    const direction = e.evt.deltaY > 0 ? -1 : 1;
    const factor = 1.08;
    let newScale = direction > 0 ? oldScale * factor : oldScale / factor;
    newScale = Math.max(SCALE_MIN, Math.min(SCALE_MAX, newScale));

    const mousePoint = {
      x: (pointer.x - view.x) / oldScale,
      y: (pointer.y - view.y) / oldScale,
    };
    setView({
      scale: newScale,
      x: pointer.x - mousePoint.x * newScale,
      y: pointer.y - mousePoint.y * newScale,
    });
  }

  function handleMouseDown(e: Konva.KonvaEventObject<MouseEvent>) {
    const stage = stageRef.current;
    if (!stage) return;
    if (tool === "select") return; // panning handled by draggable Stage
    const w = toWorld(stage);

    if (tool === "pen") {
      const id = nextId("pen");
      drawingId.current = id;
      session.board.setShape({
        id,
        type: "pen",
        color: strokeColor,
        strokeWidth,
        points: [w.x, w.y],
        createdBy: userId,
      });
    } else if (tool === "rectangle") {
      const id = nextId("rect");
      drawingId.current = id;
      session.board.setShape({
        id,
        type: "rectangle",
        color: strokeColor,
        strokeWidth,
        points: [],
        x: w.x,
        y: w.y,
        width: 0,
        height: 0,
        createdBy: userId,
      });
    }
    setDraftTick((t) => t + 1);
  }

  function handleMouseMove(e: Konva.KonvaEventObject<MouseEvent>) {
    const stage = stageRef.current;
    if (!stage) return;
    const w = toWorld(stage);

    // Broadcast cursor (BoardSession throttles to CURSOR_THROTTLE_HZ).
    session.sendCursor(w.x, w.y);

    const id = drawingId.current;
    if (!id) return;
    const existing = session.board.shapes.get(id);
    if (!existing) return;

    if (existing.type === "pen") {
      session.board.setShape({
        ...existing,
        points: [...existing.points, w.x, w.y],
      });
    } else if (existing.type === "rectangle") {
      session.board.setShape({
        ...existing,
        width: w.x - (existing.x ?? 0),
        height: w.y - (existing.y ?? 0),
      });
    }
    setDraftTick((t) => t + 1);
  }

  function handleMouseUp() {
    drawingId.current = null;
  }

  return (
    <div className="canvas-root">
      <Stage
        ref={stageRef}
        width={window.innerWidth}
        height={window.innerHeight}
        x={view.x}
        y={view.y}
        scaleX={view.scale}
        scaleY={view.scale}
        draggable={tool === "select"}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onDragEnd={(e) =>
          setView((v) => ({ ...v, x: e.target.x(), y: e.target.y() }))
        }
      >
        <Layer>
          {shapes.map((s) => renderShape(s))}
        </Layer>
        <Layer listening={false}>
          <Cursors scale={view.scale} />
        </Layer>
      </Stage>
    </div>
  );
}

function renderShape(s: Shape) {
  if (s.type === "pen") {
    return (
      <Line
        key={s.id}
        points={s.points}
        stroke={s.color}
        strokeWidth={s.strokeWidth}
        lineCap="round"
        lineJoin="round"
        tension={0.2}
      />
    );
  }
  if (s.type === "rectangle") {
    const x = Math.min(s.x ?? 0, (s.x ?? 0) + (s.width ?? 0));
    const y = Math.min(s.y ?? 0, (s.y ?? 0) + (s.height ?? 0));
    return (
      <Rect
        key={s.id}
        x={x}
        y={y}
        width={Math.abs(s.width ?? 0)}
        height={Math.abs(s.height ?? 0)}
        stroke={s.color}
        strokeWidth={s.strokeWidth}
      />
    );
  }
  return null;
}
