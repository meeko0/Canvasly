// Floating toolbar: real select/pen/rectangle tool switching via the zustand
// store, plus undo/redo and a color/width control. Other tools are stubs.
import { useBoardStore, type Tool } from "../../store/useBoardStore.js";
import type { BoardSession } from "../../lib/yjs/BoardSession.js";

export interface ToolbarProps {
  session: BoardSession;
}

interface ToolDef {
  id: Tool;
  label: string;
  glyph: string;
  real: boolean;
}

const TOOLS: ToolDef[] = [
  { id: "select", label: "Select / pan", glyph: "↖", real: true },
  { id: "pen", label: "Pen", glyph: "✏", real: true },
  { id: "rectangle", label: "Rectangle", glyph: "▭", real: true },
  // TODO(canvasly): these switch the store value but have no canvas behavior
  // yet — Canvas.tsx only implements pen + rectangle.
];

// TODO(canvasly): stubbed tools — render disabled so the UI shows the roadmap.
const STUB_TOOLS: Array<{ label: string; glyph: string }> = [
  { label: "Ellipse", glyph: "◯" },
  { label: "Line", glyph: "╱" },
  { label: "Arrow", glyph: "➜" },
  { label: "Text", glyph: "T" },
  { label: "Sticky note", glyph: "▥" },
  { label: "Eraser", glyph: "⌫" },
  { label: "Highlighter", glyph: "▰" },
  { label: "Image", glyph: "🖼" },
];

export function Toolbar({ session }: ToolbarProps) {
  const tool = useBoardStore((s) => s.tool);
  const setTool = useBoardStore((s) => s.setTool);
  const strokeColor = useBoardStore((s) => s.strokeColor);
  const setStrokeColor = useBoardStore((s) => s.setStrokeColor);
  const strokeWidth = useBoardStore((s) => s.strokeWidth);
  const setStrokeWidth = useBoardStore((s) => s.setStrokeWidth);

  return (
    <div className="toolbar" role="toolbar" aria-label="Drawing tools">
      {TOOLS.map((t) => (
        <button
          key={t.id}
          className={`tool-btn${tool === t.id ? " active" : ""}`}
          title={t.label}
          aria-pressed={tool === t.id}
          onClick={() => setTool(t.id)}
        >
          <span aria-hidden>{t.glyph}</span>
        </button>
      ))}

      <span className="toolbar-sep" />

      <button
        className="tool-btn"
        title="Undo (local)"
        onClick={() => session.board.undo()}
      >
        <span aria-hidden>⟲</span>
      </button>
      <button
        className="tool-btn"
        title="Redo (local)"
        onClick={() => session.board.redo()}
      >
        <span aria-hidden>⟳</span>
      </button>

      <span className="toolbar-sep" />

      <input
        type="color"
        aria-label="Stroke color"
        value={strokeColor}
        onChange={(e) => setStrokeColor(e.target.value)}
      />
      <input
        type="range"
        aria-label="Stroke width"
        min={1}
        max={24}
        value={strokeWidth}
        onChange={(e) => setStrokeWidth(Number(e.target.value))}
      />

      <span className="toolbar-sep" />

      {STUB_TOOLS.map((t) => (
        <button
          key={t.label}
          className="tool-btn disabled"
          title={`${t.label} (coming soon)`}
          disabled
        >
          <span aria-hidden>{t.glyph}</span>
        </button>
      ))}
    </div>
  );
}
