// Light/dark theme toggle (real) — flips the ThemeContext.
import { useTheme } from "../../theme/ThemeContext.js";

export function ThemeToggle() {
  const { theme, toggle } = useTheme();
  return (
    <button
      className="theme-toggle"
      onClick={toggle}
      title={`Switch to ${theme === "light" ? "dark" : "light"} mode`}
      aria-label="Toggle theme"
    >
      {theme === "light" ? "🌙" : "☀"}
    </button>
  );
}
