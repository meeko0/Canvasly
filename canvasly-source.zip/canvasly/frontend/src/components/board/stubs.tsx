// Typed placeholder components for board features not in the vertical slice.
// Each exports a real (compiling) component so imports resolve; behavior is
// deferred. See the per-export TODO(canvasly) markers.
import type { ReactElement } from "react";

export interface StubProps {
  boardId: string;
}

// TODO(canvasly): live minimap overview of the whole board with a viewport box.
export function Minimap(_props: StubProps): ReactElement {
  return <div className="stub stub-minimap" data-stub="minimap" />;
}

// TODO(canvasly): version-history timeline backed by BoardSnapshotRow rows.
export function VersionHistory(_props: StubProps): ReactElement {
  return <div className="stub" data-stub="version-history" hidden />;
}

// TODO(canvasly): share dialog — invite by email, set Role (owner/editor/viewer).
export function ShareDialog(_props: StubProps): ReactElement {
  return <div className="stub" data-stub="share-dialog" hidden />;
}

// TODO(canvasly): follow-mode — lock viewport to a selected peer's camera.
export function FollowMode(_props: StubProps): ReactElement {
  return <div className="stub" data-stub="follow-mode" hidden />;
}

// TODO(canvasly): template gallery to seed a new board from presets.
export function TemplatePicker(_props: StubProps): ReactElement {
  return <div className="stub" data-stub="templates" hidden />;
}

// TODO(canvasly): first-run onboarding tour (coach marks over the toolbar).
export function OnboardingTour(): ReactElement {
  return <div className="stub" data-stub="onboarding" hidden />;
}

// TODO(canvasly): comment threads anchored to board coordinates.
export function Comments(_props: StubProps): ReactElement {
  return <div className="stub" data-stub="comments" hidden />;
}
