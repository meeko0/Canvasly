// Canvasly infrastructure stack: Cognito, DynamoDB, S3, API GW WebSocket, Lambdas, IAM, CloudWatch.
import * as path from "node:path";
import {
  Stack,
  StackProps,
  RemovalPolicy,
  Duration,
  CfnOutput,
  SecretValue,
} from "aws-cdk-lib";
import { Construct } from "constructs";
import * as cognito from "aws-cdk-lib/aws-cognito";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as iam from "aws-cdk-lib/aws-iam";
import * as logs from "aws-cdk-lib/aws-logs";
import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import * as lambda from "aws-cdk-lib/aws-lambda";
import { NodejsFunction, OutputFormat } from "aws-cdk-lib/aws-lambda-nodejs";
import * as apigwv2 from "aws-cdk-lib/aws-apigatewayv2";
import * as apigwv2Integrations from "aws-cdk-lib/aws-apigatewayv2-integrations";
import * as apigwv2Authorizers from "aws-cdk-lib/aws-apigatewayv2-authorizers";

/**
 * Directory holding the backend WebSocket handler sources (../backend/src/handlers).
 * Resolved from the infra package root (process.cwd() when cdk runs) so it is
 * stable whether this module runs from source or from the compiled dist/ tree.
 */
const INFRA_ROOT = process.env.CANVASLY_INFRA_ROOT ?? process.cwd();
const HANDLERS_DIR = path.resolve(
  INFRA_ROOT,
  "..",
  "backend",
  "src",
  "handlers",
);

/** Deployment environment selected via `-c env=dev|prod`. */
export type DeployEnv = "dev" | "prod";

export interface CanvaslyStackProps extends StackProps {
  /** Target environment; drives resource/stack naming and prod-vs-dev policy. */
  deployEnv: DeployEnv;
}

/** Custom CloudWatch metric namespace for app-level metrics (active connections, message volume). */
export const CANVASLY_METRICS_NAMESPACE = "Canvasly/App";

/** Client -> server WebSocket route keys that integrate to a Lambda. */
const CUSTOM_ROUTES = [
  "joinBoard",
  "leaveBoard",
  "syncUpdate",
  "cursorMove",
  "presence",
  "ping",
] as const;

type CustomRoute = (typeof CUSTOM_ROUTES)[number];
/** Every handler file we expect under ../backend/src/handlers/<name>.ts. */
type HandlerName = "connect" | "disconnect" | "authorizer" | CustomRoute;

export class CanvaslyStack extends Stack {
  constructor(scope: Construct, id: string, props: CanvaslyStackProps) {
    super(scope, id, props);

    const env = props.deployEnv;
    const prefix = `canvasly-${env}`;
    const isProd = env === "prod";
    // Retain data in prod; allow clean teardown in dev.
    const dataRemoval = isProd ? RemovalPolicy.RETAIN : RemovalPolicy.DESTROY;

    // -----------------------------------------------------------------------
    // Cognito: user pool + client (email/password, password reset, Google IdP placeholder)
    // -----------------------------------------------------------------------
    const userPool = new cognito.UserPool(this, "UserPool", {
      userPoolName: `${prefix}-users`,
      selfSignUpEnabled: true,
      signInAliases: { email: true },
      autoVerify: { email: true },
      // Password reset via verification code to the user's email.
      accountRecovery: cognito.AccountRecovery.EMAIL_ONLY,
      standardAttributes: {
        email: { required: true, mutable: true },
        fullname: { required: false, mutable: true },
      },
      passwordPolicy: {
        minLength: 8,
        requireLowercase: true,
        requireUppercase: true,
        requireDigits: true,
        requireSymbols: false,
      },
      removalPolicy: dataRemoval,
    });

    // Google IdP placeholder: wired structurally so the client can list it, but
    // the real secret is injected out-of-band (never in code). Enabled only when
    // a client ID is supplied via context to avoid synthesizing an invalid config.
    // TODO(canvasly): supply GOOGLE client id/secret via `-c googleClientId=... -c googleClientSecret=...`
    const googleClientId = this.node.tryGetContext("googleClientId") as string | undefined;
    const googleClientSecret = this.node.tryGetContext("googleClientSecret") as string | undefined;
    const supportedIdentityProviders = [
      cognito.UserPoolClientIdentityProvider.COGNITO,
    ];
    if (googleClientId && googleClientSecret) {
      const google = new cognito.UserPoolIdentityProviderGoogle(this, "GoogleIdP", {
        userPool,
        clientId: googleClientId,
        clientSecretValue: SecretValue.unsafePlainText(googleClientSecret),
        scopes: ["email", "profile", "openid"],
        attributeMapping: {
          email: cognito.ProviderAttribute.GOOGLE_EMAIL,
          fullname: cognito.ProviderAttribute.GOOGLE_NAME,
        },
      });
      supportedIdentityProviders.push(
        cognito.UserPoolClientIdentityProvider.GOOGLE,
      );
      // Ensure the client depends on the IdP so creation ordering is correct.
      this.node.addDependency(google);
    }

    const userPoolClient = new cognito.UserPoolClient(this, "UserPoolClient", {
      userPool,
      userPoolClientName: `${prefix}-web`,
      generateSecret: false, // public SPA client (PKCE)
      authFlows: {
        userPassword: true,
        userSrp: true,
      },
      supportedIdentityProviders,
      oAuth: {
        flows: { authorizationCodeGrant: true },
        scopes: [
          cognito.OAuthScope.EMAIL,
          cognito.OAuthScope.OPENID,
          cognito.OAuthScope.PROFILE,
        ],
      },
      preventUserExistenceErrors: true,
    });

    // -----------------------------------------------------------------------
    // DynamoDB tables (all on-demand + encryption-at-rest)
    // -----------------------------------------------------------------------
    const connectionsTable = new dynamodb.Table(this, "ConnectionsTable", {
      tableName: `${prefix}-connections`,
      partitionKey: { name: "connectionId", type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      timeToLiveAttribute: "ttl",
      removalPolicy: dataRemoval,
      pointInTimeRecovery: isProd,
    });
    connectionsTable.addGlobalSecondaryIndex({
      indexName: "byBoard",
      partitionKey: { name: "boardId", type: dynamodb.AttributeType.STRING },
      projectionType: dynamodb.ProjectionType.ALL,
    });

    const boardsTable = new dynamodb.Table(this, "BoardsTable", {
      tableName: `${prefix}-boards`,
      partitionKey: { name: "boardId", type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      removalPolicy: dataRemoval,
      pointInTimeRecovery: isProd,
    });

    const boardMembersTable = new dynamodb.Table(this, "BoardMembersTable", {
      tableName: `${prefix}-board-members`,
      partitionKey: { name: "boardId", type: dynamodb.AttributeType.STRING },
      sortKey: { name: "userId", type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      removalPolicy: dataRemoval,
      pointInTimeRecovery: isProd,
    });

    const boardSnapshotsTable = new dynamodb.Table(this, "BoardSnapshotsTable", {
      tableName: `${prefix}-board-snapshots`,
      partitionKey: { name: "boardId", type: dynamodb.AttributeType.STRING },
      sortKey: { name: "version", type: dynamodb.AttributeType.NUMBER },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      removalPolicy: dataRemoval,
      pointInTimeRecovery: isProd,
    });

    // -----------------------------------------------------------------------
    // S3 snapshots bucket (private, block all public access, TLS-only, encrypted)
    // -----------------------------------------------------------------------
    const snapshotsBucket = new s3.Bucket(this, "SnapshotsBucket", {
      bucketName: `${prefix}-snapshots-${this.account}`,
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      encryption: s3.BucketEncryption.S3_MANAGED,
      enforceSSL: true, // adds the aws:SecureTransport=false deny bucket policy
      versioned: isProd,
      removalPolicy: dataRemoval,
      autoDeleteObjects: !isProd,
    });

    // -----------------------------------------------------------------------
    // WebSocket API (route selection expression $request.body.action)
    // -----------------------------------------------------------------------
    const webSocketApi = new apigwv2.WebSocketApi(this, "WebSocketApi", {
      apiName: `${prefix}-ws`,
      routeSelectionExpression: "$request.body.action",
    });

    const stageName = env;
    const webSocketStage = new apigwv2.WebSocketStage(this, "WebSocketStage", {
      webSocketApi,
      stageName,
      autoDeploy: true,
    });

    // The management (execute-api) endpoint broadcast Lambdas post back through.
    const wsManageEndpoint = `https://${webSocketApi.apiId}.execute-api.${this.region}.amazonaws.com/${stageName}`;

    // -----------------------------------------------------------------------
    // Lambdas: one NodejsFunction per route -> ../backend/src/handlers/<route>.ts
    // -----------------------------------------------------------------------
    const commonEnv: Record<string, string> = {
      CONNECTIONS_TABLE: connectionsTable.tableName,
      BOARDS_TABLE: boardsTable.tableName,
      BOARD_MEMBERS_TABLE: boardMembersTable.tableName,
      BOARD_SNAPSHOTS_TABLE: boardSnapshotsTable.tableName,
      SNAPSHOTS_BUCKET: snapshotsBucket.bucketName,
      WS_API_ENDPOINT: wsManageEndpoint,
      METRICS_NAMESPACE: CANVASLY_METRICS_NAMESPACE,
      COGNITO_USER_POOL_ID: userPool.userPoolId,
      COGNITO_CLIENT_ID: userPoolClient.userPoolClientId,
    };

    const logRetention = isProd
      ? logs.RetentionDays.ONE_MONTH
      : logs.RetentionDays.ONE_WEEK;

    const makeHandler = (name: HandlerName): NodejsFunction =>
      new NodejsFunction(this, `Fn-${name}`, {
        functionName: `${prefix}-${name}`,
        entry: path.join(HANDLERS_DIR, `${name}.ts`),
        handler: "handler",
        runtime: lambda.Runtime.NODEJS_22_X,
        memorySize: 256,
        timeout: Duration.seconds(15),
        environment: commonEnv,
        logRetention,
        bundling: {
          format: OutputFormat.ESM,
          minify: isProd,
          sourceMap: !isProd,
          target: "node22",
          externalModules: ["@aws-sdk/*"], // provided by the Lambda runtime
        },
      });

    // Build every handler. $connect/$disconnect use fixed keys; the rest map 1:1.
    const connectFn = makeHandler("connect");
    const disconnectFn = makeHandler("disconnect");
    // Request authorizer that verifies the Cognito JWT at $connect and echoes
    // the identity into the connection's request context for every later route.
    const authorizerFn = makeHandler("authorizer");
    const routeFns = new Map<CustomRoute, NodejsFunction>();
    for (const route of CUSTOM_ROUTES) {
      routeFns.set(route, makeHandler(route));
    }

    // -----------------------------------------------------------------------
    // IAM grants — least privilege per Lambda
    // -----------------------------------------------------------------------
    // execute-api:ManageConnections for Lambdas that broadcast to other sockets.
    const broadcastRoutes: ReadonlySet<CustomRoute> = new Set([
      "joinBoard",
      "leaveBoard",
      "syncUpdate",
      "cursorMove",
      "presence",
    ]);
    const manageConnectionsPolicy = new iam.PolicyStatement({
      actions: ["execute-api:ManageConnections"],
      resources: [
        `arn:aws:execute-api:${this.region}:${this.account}:${webSocketApi.apiId}/${stageName}/POST/@connections/*`,
      ],
    });

    // $connect: writes a Connection row, reads board + membership to authorize.
    connectionsTable.grantWriteData(connectFn);
    boardsTable.grantReadData(connectFn);
    boardMembersTable.grantReadData(connectFn);

    // $disconnect: removes the Connection row; may notify peers.
    connectionsTable.grantReadWriteData(disconnectFn);
    disconnectFn.addToRolePolicy(manageConnectionsPolicy);

    for (const [route, fn] of routeFns) {
      switch (route) {
        case "joinBoard":
          // Reads membership/board, reads connections for peer list, writes its own row,
          // reads snapshot index + presigns from S3, broadcasts userJoined.
          boardMembersTable.grantReadData(fn);
          boardsTable.grantReadData(fn);
          connectionsTable.grantReadWriteData(fn);
          boardSnapshotsTable.grantReadData(fn);
          snapshotsBucket.grantRead(fn);
          break;
        case "leaveBoard":
          connectionsTable.grantReadWriteData(fn);
          break;
        case "syncUpdate":
          // Role check (membership), fan-out to peers (connections by board),
          // periodic compaction writes a snapshot to S3 + an index row.
          boardMembersTable.grantReadData(fn);
          connectionsTable.grantReadData(fn);
          boardSnapshotsTable.grantReadWriteData(fn);
          snapshotsBucket.grantReadWrite(fn);
          break;
        case "cursorMove":
        case "presence":
          // Ephemeral fan-out only: needs the board's connection list.
          connectionsTable.grantReadData(fn);
          break;
        case "ping":
          // Pong is a direct reply; refreshes the connection TTL.
          connectionsTable.grantWriteData(fn);
          break;
      }
      if (broadcastRoutes.has(route)) {
        fn.addToRolePolicy(manageConnectionsPolicy);
      }
    }

    // -----------------------------------------------------------------------
    // Wire routes to integrations
    // -----------------------------------------------------------------------
    webSocketApi.addRoute("$connect", {
      integration: new apigwv2Integrations.WebSocketLambdaIntegration(
        "ConnectIntegration",
        connectFn,
      ),
      authorizer: new apigwv2Authorizers.WebSocketLambdaAuthorizer(
        "ConnectAuthorizer",
        authorizerFn,
        {
          // Identity taken from the JWT in the query string. The verified
          // identity is returned in the authorizer context and persists on the
          // connection, so joinBoard/syncUpdate read it via requestContext.
          identitySource: ["route.request.querystring.token"],
        },
      ),
    });
    webSocketApi.addRoute("$disconnect", {
      integration: new apigwv2Integrations.WebSocketLambdaIntegration(
        "DisconnectIntegration",
        disconnectFn,
      ),
    });
    for (const [route, fn] of routeFns) {
      webSocketApi.addRoute(route, {
        integration: new apigwv2Integrations.WebSocketLambdaIntegration(
          `${route}Integration`,
          fn,
        ),
      });
    }

    // Grant every function permission to post back to connected clients via the stage.
    // (execute-api:ManageConnections resource already scoped above; also the stage
    //  grants the invoke path via the integration automatically.)

    // -----------------------------------------------------------------------
    // CloudWatch: a metric alarm on aggregate Lambda errors across all functions.
    // -----------------------------------------------------------------------
    // TODO(canvasly): emit custom metrics in the namespace CANVASLY_METRICS_NAMESPACE
    //   ("Canvasly/App") from the handlers: ActiveConnections (gauge) and
    //   MessagesProcessed (count) dimensioned by { Env, Route }. The alarm below
    //   watches the AWS/Lambda Errors metric; app metrics get their own alarms once emitted.
    const allFns: NodejsFunction[] = [connectFn, disconnectFn, ...routeFns.values()];
    const errorMetrics = allFns.map((fn) =>
      fn.metricErrors({ period: Duration.minutes(5), statistic: "Sum" }),
    );
    const totalErrors = new cloudwatch.MathExpression({
      expression: errorMetrics.map((_, i) => `e${i}`).join(" + "),
      usingMetrics: Object.fromEntries(
        errorMetrics.map((m, i) => [`e${i}`, m]),
      ),
      label: "TotalLambdaErrors",
      period: Duration.minutes(5),
    });
    new cloudwatch.Alarm(this, "LambdaErrorsAlarm", {
      alarmName: `${prefix}-lambda-errors`,
      alarmDescription: "Any Canvasly WebSocket Lambda is erroring.",
      metric: totalErrors,
      threshold: 1,
      evaluationPeriods: 1,
      comparisonOperator:
        cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
      treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
    });

    // -----------------------------------------------------------------------
    // Outputs (also written to cdk-outputs.json via --outputs-file on deploy)
    // -----------------------------------------------------------------------
    const wsUrlOut = new CfnOutput(this, "WebSocketURL", {
      value: webSocketStage.url, // wss://.../<stage>
      description: "WebSocket connection URL for clients.",
    });
    wsUrlOut.overrideLogicalId("WebSocketURL");

    const userPoolIdOut = new CfnOutput(this, "UserPoolIdOutput", {
      value: userPool.userPoolId,
    });
    userPoolIdOut.overrideLogicalId("UserPoolId");

    const userPoolClientIdOut = new CfnOutput(this, "UserPoolClientIdOutput", {
      value: userPoolClient.userPoolClientId,
    });
    userPoolClientIdOut.overrideLogicalId("UserPoolClientId");

    const snapshotsBucketOut = new CfnOutput(this, "SnapshotsBucketOutput", {
      value: snapshotsBucket.bucketName,
    });
    snapshotsBucketOut.overrideLogicalId("SnapshotsBucket");
  }
}
